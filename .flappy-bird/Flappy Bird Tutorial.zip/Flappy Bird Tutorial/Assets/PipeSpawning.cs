﻿using UnityEngine;
using System.Collections;

public class PipeSpawning : MonoBehaviour {
	public int SpawnRateMax;
	public int SpawnRateMin;
	public int MinHeight;
	public int MaxHeight;
	public GameObject pipe;

	void Start()
	{
		StartCoroutine ("Spawn");
	}

	IEnumerator Spawn()
	{
		yield return new WaitForSeconds (Random.Range (SpawnRateMin, SpawnRateMax));

		Instantiate (pipe, new Vector3 (this.transform.position.x, Random.Range (MinHeight, MaxHeight), this.transform.position.z), this.transform.rotation);

		StartCoroutine ("Spawn");
	}
}

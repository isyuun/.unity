﻿using System/*, Console*/;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;
using System.Reflection;
using System.IO;

namespace ConsoleApp1
{
    class Class1
    {
    }

    class Program
    {
        /*var _tmp = 10;*/
        enum Zodiac { MOUSE = 0, COW = 1, TIGER = 2, RABBIT = 3, DRAGON = 4, SNAKE = 5, HORSE = 6, SHEEP = 7, Monkey = 8, Rooster = 9, Dog = 10, Pig = 11, };
        enum Direct { IDLE = 0, LEFT = ConsoleKey.LeftArrow, UP = ConsoleKey.UpArrow, RIGHT = ConsoleKey.RightArrow, DOWN = ConsoleKey.DownArrow, };
        enum Estate { IDLE = 0, EXPAND = 1, SHIRINK = 2, };
        enum UpDown { IDLE = 0, UP = 1, DOWN = -1, };

        const string HEYJUDE = "Hey Jude ";
        const string DONT = "don't ";
        const string MAKEITBETTER = "make it bad ";
        const string BEAFRAID = "be afraid";
        const string LETMEDOWN = "let me down ";
        const string TAKESADSONG = "take a sad song and make it better.";
        const string YOUWERE = "you were made to go out and get her.";
        const string YOUHAVE = "you have found her, now go and get her.";
        const string REMEMBERTO = "remember to ";
        const string LETHERHEART = "let her into you heart.";
        const string LETHERSKIN = "let her under you skin.";
        const string THENYOU = "then you ";
        const string CANSTART = "can start ";
        const string BEGIN = "begin";
        const string TOMAKE = "to make better.";
        const string BETTERBETTER = "better better better better waaaaa~";
        const string NA = "na~";
        //LinkedList<string> LINE0 = new LinkedList<string>(Arrays.asList(HEYJUDE, DONT));
        List<string> LINE1 = new List<string>() { HEYJUDE, DONT, MAKEITBETTER, TAKESADSONG, REMEMBERTO, LETHERHEART, THENYOU, CANSTART, TOMAKE, };
        List<string> LINE2 = new List<string>() { HEYJUDE, DONT, BEAFRAID, YOUWERE, REMEMBERTO, LETHERSKIN };
        List<string> LINE3 = new List<string>() { HEYJUDE, DONT, LETMEDOWN, YOUHAVE, REMEMBERTO, LETHERSKIN };

        static void Main(string[] args)
        {
            DateTime st = DateTime.Now, et = DateTime.Now;

            //Console.Write(L"Hell, Wold!!!\n";
            Console.WriteLine("Hell, World!!!");
            Console.WriteLine("월컴, 투헬!!!");
            Console.WriteLine("Marshal.SizeOf('A'):" + Marshal.SizeOf('A') + "\tsizeof(char):" + sizeof(char));
            //Console.WriteLine('A');
            Console.WriteLine("Marshal.SizeOf('A'):" + Marshal.SizeOf('A') + "\tMarshal.SizeOf(typeof(char)):" + Marshal.SizeOf(typeof(char)));
            //Console.WriteLine('ㄱ');
            Console.WriteLine("Marshal.SizeOf('ㄱ'):" + Marshal.SizeOf('ㄱ') + "\tMarshal.SizeOf(typeof(char)):" + Marshal.SizeOf(typeof(char)));
            Console.WriteLine();
            //Console.Write("hit any key to continue...");
            //Console.Read();

            ///*강의:4/24*/
            //Console.Write("Console.Write.");
            //Console.WriteLine("Console.WriteLine.");
            //Console.WriteLine(1 + 2);
            //Console.WriteLine(1 - 2);
            //Console.WriteLine(1 * 2);
            //Console.WriteLine(1 / 2);
            ////Console.WriteLine(1 % 0);
            //Console.WriteLine();
            //Console.WriteLine(4 % 3);
            //Console.WriteLine(-4 % 3);
            //Console.WriteLine(4 % -3);
            //Console.WriteLine(-4 % -3);
            //Console.WriteLine();
            //Console.WriteLine(4 * 3);
            //Console.WriteLine(-4 * 3);
            //Console.WriteLine(4 * -3);
            //Console.WriteLine(-4 * -3);
            //Console.WriteLine();
            //Console.WriteLine("'가' + '힣':" + ('가' + '힣') + "\tMarshal.SizeOf('가' + '힣'):" + Marshal.SizeOf('가' + '힣'));
            //Console.WriteLine("'힣' - '가'" + ('힣' - '가'));
            //Console.WriteLine();
            //try
            //{
            //    Console.WriteLine("안냐하세요"[4]);
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
            //Console.WriteLine("가" + 1 + '힣');
            //Console.WriteLine("끝...\n");

            //Console.WriteLine("#### size of ####");
            //Console.WriteLine("Marshal.SizeOf(typeof(short)):" + Marshal.SizeOf(typeof(short)));
            //Console.WriteLine("Marshal.SizeOf(typeof(ushort)):" + Marshal.SizeOf(typeof(ushort)));
            ////Console.WriteLine(short.MaxValue);
            ////Console.WriteLine(short.MinValue);
            //Console.WriteLine("Marshal.SizeOf(typeof(int)):" + Marshal.SizeOf(typeof(int)));
            //Console.WriteLine("Marshal.SizeOf(typeof(uint)):" + Marshal.SizeOf(typeof(uint)));
            ////Console.WriteLine(int.MaxValue);
            ////Console.WriteLine(int.MinValue);
            //Console.WriteLine("Marshal.SizeOf(typeof(long)):" + Marshal.SizeOf(typeof(long)));
            //Console.WriteLine("Marshal.SizeOf(typeof(ulong)):" + Marshal.SizeOf(typeof(ulong)));
            ////Console.WriteLine(long.MaxValue);
            ////Console.WriteLine(long.MinValue);
            //Console.WriteLine("Marshal.SizeOf(typeof(float)):" + Marshal.SizeOf(typeof(float)));
            ////Console.WriteLine(float.MinValue);
            ////Console.WriteLine(float.MinValue);
            //Console.WriteLine("Marshal.SizeOf(typeof(double)):" + Marshal.SizeOf(typeof(double)));
            ////Console.WriteLine(double.MinValue);
            ////Console.WriteLine(double.MinValue);
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    double a = 52.273, b = 103.32;
            //    Console.WriteLine(a + b);
            //    Console.WriteLine(a - b);
            //    Console.WriteLine(a * b);
            //    Console.WriteLine(a / b);
            //    Console.WriteLine(a % b);
            //    Console.WriteLine();
            //    int num = 10;
            //    Console.WriteLine(num);
            //    Console.WriteLine(num++ + ":num++");
            //    Console.WriteLine(num-- + ":num--");
            //    Console.WriteLine(num);
            //    Console.WriteLine();
            //    Console.WriteLine(num);
            //    Console.WriteLine(++num + ":++num");
            //    Console.WriteLine(--num + ":--num");
            //    Console.WriteLine(num);
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    /*var _tmp = 10;*/
            //    /*Console.WriteLine("_tmp\t" + _tmp.GetType() + "\t" + sizeof(var) + "\t" + _tmp);*/
            //    /*var __tmp;*/
            //    int _int = 273;
            //    long _long = 1234567890123456789;
            //    float _float = 0.1234567890123456789012345678901234567890123456789012345678901234567890f;
            //    double _double = 1.1234567890123456789012345678901234567890123456789012345678901234567890f;
            //    char _char = 'A';
            //    char __char = 'ㄱ';
            //    string _string = "1234567890abcdefghijklmnopqrstuvwxyzㄱㄴㄷㄻㅄㅇㅈㅊㅋㅌㅍㅎ";
            //    Console.WriteLine("_int\t" + _int.GetType() + "\t" + sizeof(int) + "\t" + _int);
            //    Console.WriteLine("_long\t" + _long.GetType() + "\t" + sizeof(long) + "\t" + _long);
            //    Console.WriteLine("_float\t" + _float.GetType() + "\t" + sizeof(float) + "\t" + _float);
            //    Console.WriteLine("_double\t" + _double.GetType() + "\t" + sizeof(double) + "\t" + _double);
            //    Console.WriteLine("_char\t" + _char.GetType() + "\t" + sizeof(char) + "\t" + _char);
            //    Console.WriteLine("__char\t" + __char.GetType() + "\t" + sizeof(char) + "\t" + __char);
            //    Console.WriteLine("_string\t" + _string.GetType() + "\t" + (_string).Length + "\t" + _string);
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    /*string input = Console.ReadLine();*/
            //    /*Console.WriteLine(input);*/
            //    /*Console.WriteLine();*/
            //    long lNum = 1234567890L + 1234567890L;
            //    /*long lNum = 1234L + 1234L;*/
            //    int iNum = (int)lNum;
            //    Console.WriteLine(iNum);
            //    /*lNum = iNum = (int)(1234567890L + 1234567890L);*/
            //    lNum = iNum;
            //    Console.WriteLine(lNum);
            //    string nStr = "1234567890";
            //    Console.WriteLine();
            //    int iNum2 = Int32.Parse(nStr);
            //    Console.WriteLine(iNum2);
            //    Console.WriteLine(iNum2.GetType());
            //    long lNum2 = long.Parse(nStr);
            //    Console.WriteLine(lNum2);
            //    Console.WriteLine(lNum2.GetType());
            //    float fNum2 = float.Parse(nStr);
            //    Console.WriteLine(fNum2);
            //    Console.WriteLine(fNum2.GetType());
            //    double dNum2 = double.Parse(nStr);
            //    Console.WriteLine(dNum2);
            //    Console.WriteLine(dNum2.GetType());
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    /*var _var = Console.ReadLine();*/
            //    /*Console.WriteLine(_var);*/
            //    /*Console.WriteLine(_var.GetType());*/
            //    int _int;
            //    try
            //    {
            //        _int = int.Parse(Console.ReadLine());
            //    }
            //    catch (Exception)
            //    {
            //        break;
            //        throw;
            //    }
            //    Console.WriteLine(_int);
            //    Console.WriteLine(_int.GetType());
            //    Console.WriteLine();
            //    int iNum = 1234;
            //    Console.WriteLine(iNum.ToString());
            //    Console.WriteLine(1234.ToString());
            //    Console.WriteLine(3.14.ToString());
            //    Console.WriteLine((iNum).ToString());
            //    Console.WriteLine((1234).ToString());
            //    Console.WriteLine((3.14).ToString());
            //    Console.WriteLine();
            //    double pi = 3.141592;
            //    Console.WriteLine(pi.ToString());
            //    Console.WriteLine(pi.ToString("0"));
            //    Console.WriteLine(pi.ToString("0.0"));
            //    Console.WriteLine(pi.ToString("0.00"));
            //    Console.WriteLine(pi.ToString("0.000"));
            //    Console.WriteLine(pi.ToString("0.0000"));
            //    Console.WriteLine(pi.ToString("0.00000"));
            //    Console.WriteLine(pi.ToString("0.000000"));
            //    Console.WriteLine(pi.ToString("0.0000000"));
            //    Console.WriteLine();
            //    Console.WriteLine(52 + 273);
            //    Console.WriteLine("52" + 273);
            //    Console.WriteLine(52 + "273");
            //    Console.WriteLine("52" + "273");
            //    Console.WriteLine("" + 52 + 273);
            //    Console.WriteLine(52 + 273 + "");
            //    Console.WriteLine();
            //    Console.WriteLine(bool.Parse("false"));
            //    Console.WriteLine(bool.Parse("False"));
            //    Console.WriteLine(bool.Parse("fAlse"));
            //    /*Console.WriteLine(bool.Parse("0"));*/
            //    /*Console.WriteLine(bool.Parse(0));*/
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Console.Write("input number in cm:");
            //    float cm = float.Parse(Console.ReadLine()), ic = cm;
            //    ic /= 2.54f;
            //    Console.WriteLine("input number is " + cm + "cm and " + ic + "inch");
            //    Console.WriteLine();
            //    Console.Write("input radius:");
            //    /*const double PI = 3.14f;*/
            //    /*double r = double.Parse(Console.ReadLine()), r = (r * 2) * Math.PI, a = Math.Pow(r, 2) * Math.PI; */
            //    /*Console.WriteLine("input r is " + r + ". and round is " + (r * 2) * PI + " area is " + Math.Pow(r, 2) * PI);*/
            //    double r = double.Parse(Console.ReadLine())/*, r = (r * 2) * Math.PI, a = Math.Pow(r, 2) * Math.PI*/;
            //    Console.WriteLine("input r is " + r + ". and round is " + (r * 2) * Math.PI + " area is " + Math.Pow(r, 2) * Math.PI);
            //    Console.WriteLine();
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            ///*강의: 4 / 24*/
            //while (true)
            //{
            //    long start = DateTime.Now.Ticks;
            //    long count = 0;
            //    while (start + 10000000 > DateTime.Now.Ticks)
            //    {
            //        Console.Clear();
            //        Console.Write("\a");
            //        Console.Write(DateTime.Now.Year);
            //        Console.Write("-");
            //        Console.Write(DateTime.Now.Month);
            //        Console.Write("-");
            //        Console.Write(DateTime.Now.Day);
            //        Console.Write(" ");
            //        Console.Write(DateTime.Now.Hour);
            //        Console.Write(":");
            //        Console.Write(DateTime.Now.Minute);
            //        Console.Write(":");
            //        Console.Write(DateTime.Now.Second);
            //        Console.Write("-");
            //        Console.Write(DateTime.Now.Millisecond);
            //        Console.WriteLine();
            //        count++;
            //    }
            //    Console.WriteLine(count);
            //    Thread.Sleep(1000);
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    int mon;
            //    Console.Write("달수를 입력하세요...:");
            //    try
            //    {
            //        mon = int.Parse(Console.ReadLine());
            //    }
            //    catch (Exception)
            //    {
            //        Console.Write("달수를 이라니깐요!!!\n");
            //        Console.Write("\n");
            //        continue;
            //    }
            //    switch (mon)
            //    {
            //        case 3:
            //        case 4:
            //        case 5:
            //            Console.Write("봄봄봄!!! 봄이 왔네요.\n");
            //            break;
            //        case 6:
            //        case 7:
            //        case 8:
            //            Console.Write("여름여름여름!!! 여름이 왔네요.\n");
            //            break;
            //        case 9:
            //        case 10:
            //        case 11:
            //            Console.Write("가을가을가을!!! 가을이 왔네요.\n");
            //            break;
            //        case 12:
            //        case 1:
            //        case 2:
            //            Console.Write("겨울겨울겨울!!! 겨울이 왔네요.\n");
            //            break;
            //        default:
            //            Console.Write(mon + "이(가) 입력 되었습니다.\n");
            //            break;
            //    }
            //    Console.Write("\n");
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Console.Write("say hi!!!:");
            //    string line = Console.ReadLine();
            //    if (line.ToLower().Contains("hi"))
            //    {
            //        Console.WriteLine("Hell, World");
            //    }
            //    else
            //    {
            //        Console.WriteLine("XXXX, World");
            //    }
            //    Console.Write("input arrow key:");
            //    ConsoleKeyInfo info = Console.ReadKey();
            //    switch (info.Key)
            //    {
            //        case ConsoleKey.LeftArrow:
            //            Console.WriteLine("←");
            //            break;
            //        case ConsoleKey.UpArrow:
            //            Console.WriteLine("↑");
            //            break;
            //        case ConsoleKey.RightArrow:
            //            Console.WriteLine("→");
            //            break;
            //        case ConsoleKey.DownArrow:
            //            Console.WriteLine("↓");
            //            break;
            //        default:
            //            break;
            //    }
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    //int i = int.Parse(Console.ReadLine());
            //    //while (i)
            //    //{
            //    //}
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    int year;
            //    Zodiac zodiac;
            //    Console.Write("input year...:");
            //    try
            //    {
            //        year = int.Parse(Console.ReadLine());
            //        zodiac = (Zodiac)Enum.Parse(typeof(Zodiac), (year % 1972).ToString());
            //    }
            //    catch (Exception)
            //    {
            //        Console.Write("I said year!!!\n");
            //        Console.Write("\n");
            //        continue;
            //    }
            //    Console.WriteLine("input year " + year + "'s zodiac is " + zodiac);
            //    switch (zodiac)
            //    {
            //        case Zodiac.MOUSE:
            //            break;
            //        case Zodiac.COW:
            //            break;
            //        case Zodiac.TIGER:
            //            break;
            //        case Zodiac.RABBIT:
            //            break;
            //        case Zodiac.DRAGON:
            //            break;
            //        case Zodiac.SNAKE:
            //            break;
            //        case Zodiac.HORSE:
            //            break;
            //        case Zodiac.SHEEP:
            //            break;
            //        case Zodiac.Monkey:
            //            break;
            //        case Zodiac.Rooster:
            //            break;
            //        case Zodiac.Dog:
            //            break;
            //        case Zodiac.Pig:
            //            break;
            //        default:
            //            break;
            //    }
            //    /*Console.ReadLine();*/
            //    /*Console.Write("\n");*/
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    int[] num = new int[2];
            //    num[0] = 0;
            //    num[1] = 1;
            //    /*num[2] = 2;*/
            //    for (int i = 0; i < num.Length; i++)
            //    {
            //        Console.WriteLine(num[i]);
            //    }
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    int[] intA = { 50, 273, 32, 65, 103 };
            //    long[] longA = { 50, 273, 32, 65, 103 };
            //    float[] floatA = { 1.0f, 2.0f, 3.0f, 4.0f, 5.0f };
            //    double[] doubleA = { 50.0f, 273.0f, 32.0f, 65.0f, 103.0f };
            //    char[] charA = { 'A', 'B', 'C', 'D', 'E', };
            //    string[] stringA = { "Aa", "Bb", "Cc", "Dd", "Ee", };
            //    for (int i = 0; i < 5; i++)
            //    {
            //        Console.WriteLine(intA[i]);
            //        Console.WriteLine(longA[i]);
            //        Console.WriteLine(floatA[i]);
            //        Console.WriteLine(doubleA[i]);
            //        Console.WriteLine(charA[i]);
            //        Console.WriteLine(stringA[i]);
            //        Console.WriteLine();
            //    }
            //    int j = 0;
            //    while (j < intA.Length)
            //    {
            //        Console.WriteLine(intA[j]);
            //        j++;
            //    }
            //    Console.WriteLine();
            //    j = 0;
            //    do
            //    {
            //        Console.WriteLine(intA[j]);
            //        j++;
            //    } while (j < intA.Length);
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    for (char c = '가'; c < ('힣' + 1); c++)
            //    {
            //        Console.WriteLine(c);
            //    }
            //    Console.WriteLine();
            //    for (char c = '힣'; c > ('가' - 1); c--)
            //    {
            //        Console.WriteLine(c);
            //    }
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    int i = 0;
            //    string[] a = { "P", "T", "B", "A", "C" };
            //    i = 0;
            //    foreach (var item in a)
            //    {
            //        i++;
            //        Console.WriteLine(i + ":" + item);
            //    }
            //    Console.WriteLine();
            //    i = 0;
            //    foreach (var item in Enum.GetNames(typeof(Zodiac)))
            //    {
            //        i++;
            //        Console.WriteLine(i + ":" + item);
            //    }
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    int num = 5;
            //    int c = num, d = num, e;
            //    string s;
            //    for (int i = 0; i < num * 2; i++)
            //    {
            //        e = (num * 2 - (d - num * 2));
            //        Console.Write("i:" + i + "c:" + c + "d:" + d + ":" + e + "\t");
            //        for (int j = 0; j < num * 2; j++)
            //        {
            //            if (i < num)
            //            {
            //                s = ((j < num && j < c - 1) || (j >= num && j < d + 1)) ? " ." : " *";
            //                Console.Write(s);
            //            }
            //            else
            //            {
            //                s = ((j < num && j > -c - 1) || (j >= num && j > e - 1)) ? " ." : " *";
            //                Console.Write(s);
            //            }
            //        }
            //        Console.WriteLine();
            //        c--;
            //        d++;
            //    }
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    for (int i = 0; i < 10; i++)
            //    {
            //        Console.WriteLine("i:" + i);
            //        for (int j = 0; j < 10; j++)
            //        {
            //            Console.WriteLine("j:" + j);
            //            goto Exit;
            //        }
            //    }
            //    Exit:;
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    string input = " Potato Tomato Banana            \n";
            //    Console.WriteLine("###" + input.Trim() + "###");
            //    string[] inputs = { "Potato", "Tomato", "Banana" };
            //    Console.WriteLine("" + string.Join(", ", inputs) + "");
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    int x = 1;
            //    while (x < 50)
            //    {
            //        Console.Clear();
            //        Console.SetCursorPosition(x, 5);
            //        if (x % 3 == 0) Console.WriteLine(" __@");
            //        else if (x % 3 == 0) Console.WriteLine("__^@");
            //        else Console.WriteLine("^_@");
            //        Thread.Sleep(100);
            //        x++;
            //    }
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Console.WriteLine("please input any key\n");
            //    Console.CursorVisible = false;
            //    int l = 0, t = 0;
            //    int lm = 3, tm = 2;
            //    int r = Console.WindowWidth - lm, b = Console.WindowHeight - tm;
            //    while (true)
            //    {
            //        ConsoleKeyInfo info = Console.ReadKey();
            //        Debug.WriteLine("(r:" + r + "-l:" + l + ", b:" + b + "-t:" + t + ")");
            //        //Direct o = (Direct)Enum.Parse(typeof(Direct), info.Key.ToString());
            //        Direct o = Direct.IDLE;
            //        switch (info.Key)
            //        {
            //            case ConsoleKey.LeftArrow:
            //                //Console.WriteLine("←");
            //                o = Direct.LEFT;
            //                l--;
            //                break;
            //            case ConsoleKey.UpArrow:
            //                //Console.WriteLine("↑");
            //                o = Direct.UP;
            //                t--;
            //                break;
            //            case ConsoleKey.RightArrow:
            //                //Console.WriteLine("→");
            //                o = Direct.LEFT;
            //                l++;
            //                break;
            //            case ConsoleKey.DownArrow:
            //                //Console.WriteLine("↓");
            //                o = Direct.UP;
            //                t++;
            //                break;
            //            default:
            //                break;
            //        }
            //        Console.Clear();
            //        bool c = false;
            //        //left
            //        if (l < 0)
            //        {
            //            c = true;
            //            l = 0;
            //        }
            //        else if (l > r)
            //        {
            //            c = true;
            //            l = r;
            //        }
            //        //top
            //        if (t < 0)
            //        {
            //            c = true;
            //            t = 0;
            //        }
            //        else if (t > b)
            //        {
            //            c = true;
            //            t = b;
            //        }
            //        Console.SetCursorPosition(l, t);
            //        String s = "^^$";
            //        if (c)
            //        {
            //            s = "^^$";
            //        }
            //        else
            //        {
            //            if (l % 3 == 0 /*|| t % 3 == 0*/) s = ("__@");
            //            else if (l % 3 == 1 /*|| t % 3 == 1*/) s = ("_^@");
            //            else s = ("^_@");
            //            switch (o)
            //            {
            //                //case Direct.IDLE:
            //                //    break;
            //                case Direct.LEFT:
            //                case Direct.RIGHT:
            //                    switch ((Estate)Enum.Parse(typeof(Estate), (l % 3).ToString()))
            //                    {
            //                        //case Estate.IDLE:
            //                        //    break;
            //                        case Estate.EXPAND:
            //                            s = ("__@");
            //                            break;
            //                        case Estate.SHIRINK:
            //                            s = ("_^@");
            //                            break;
            //                        default:
            //                            s = ("^_@");
            //                            break;
            //                    }
            //                    break;
            //                case Direct.UP:
            //                case Direct.DOWN:
            //                    switch ((Estate)Enum.Parse(typeof(Estate), (t % 3).ToString()))
            //                    {
            //                        //case Estate.IDLE:
            //                        //    break;
            //                        case Estate.EXPAND:
            //                            s = ("__@");
            //                            break;
            //                        case Estate.SHIRINK:
            //                            s = ("_^@");
            //                            break;
            //                        default:
            //                            s = ("^_@");
            //                            break;
            //                    }
            //                    break;
            //                default:
            //                    break;
            //            }
            //            switch (o)
            //            {
            //                //case Orient.IDLE:
            //                //    break;
            //                case Direct.LEFT:
            //                    break;
            //                case Direct.UP:
            //                    break;
            //                default:
            //                    break;
            //            }
            //        }
            //        Console.WriteLine(s);
            //        //Thread.Sleep(1000);
            //    }
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    long count = 0;
            //    while (true)
            //    {
            //        Random rnd = new Random();
            //        //Console.WriteLine(rnd.Next(10, 100));
            //        //Console.WriteLine(rnd.Next(10, 100));
            //        //Console.WriteLine(rnd.Next(10, 100));
            //        //Console.WriteLine(rnd.Next(10, 100));
            //        //Console.WriteLine(rnd.Next(10, 100));
            //        Console.WriteLine(rnd.NextDouble() * 100f);
            //        Console.WriteLine(rnd.NextDouble() * 100f);
            //        Console.WriteLine(rnd.NextDouble() * 100f);
            //        Console.WriteLine(rnd.NextDouble() * 100f);
            //        Console.WriteLine(rnd.NextDouble() * 100f);
            //        int c = (int)(rnd.NextDouble() * 10f);
            //        Console.WriteLine(count + "차\t" + c);
            //        Console.WriteLine();
            //        if (c == 1)
            //        {
            //            break;
            //        }
            //        count++;
            //    }
            //    Console.ReadLine();
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    int[] ia = { 1, 2, 3, 4, 5 };
            //    //List<int> il = new List<int>() { 1, 2, 3, 4, 5 };
            //    List<int> il = ia.OfType<int>().ToList();
            //    //il.Add(1);
            //    //il.Add(2);
            //    //il.Add(3);
            //    //il.Add(4);
            //    //il.Add(5);
            //    foreach (var item in il)
            //    {
            //        Console.WriteLine("count:" + il.Count + "\t" + il.IndexOf(item) + "\t" + item);
            //    }
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Console.WriteLine(Math.Abs(-52273));
            //    Console.WriteLine(Math.Ceiling(-52.273));
            //    Console.WriteLine(Math.Floor(-52.273));
            //    Console.WriteLine(Math.Max(52, 273));
            //    Console.WriteLine(Math.Min(52, 273));
            //    Console.WriteLine(Math.Round(52.273));
            //    Class1 cl1 = new Class1();
            //    Class2 cl2 = new Class2();
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Product pr1 = new Product();
            //    pr1.name = "Potato";
            //    pr1.price = 1000;
            //    Console.WriteLine("pr1:" + pr1);
            //    Product pr2 = new Product() { name = "Tomato", price = 2000 };
            //    Console.WriteLine("pr2:" + pr2);
            //    Product pr3 = new Product() { name = "Apple", price = 3000 };
            //    Console.WriteLine("pr3:" + pr3);
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    //Student[] sl;
            //    List<Student> sl = new List<Student>();
            //    sl.Add(new Student { name = "길동", grade = 9 });
            //    sl.Add(new Student { name = "근혜", grade = 1 });
            //    sl.Add(new Student { name = "기춘", grade = 2 });
            //    sl.Add(new Student { name = "병우", grade = 3 });
            //    sl.Add(new Student { name = "윤선", grade = 4 });
            //    sl.Add(new Student { name = "순실", grade = 1 });
            //    sl.Add(new Student { name = "은택", grade = 2 });
            //    sl.Add(new Student { name = "영태", grade = 3 });
            //    sl.Add(new Student { name = "병언", grade = 1 });
            //    sl.Add(new Student { name = "명박", grade = 0 });
            //    int idx = 0;
            //    Console.WriteLine();
            //    Console.WriteLine(sl.Count);
            //    foreach (var item in sl)
            //    {
            //        Console.WriteLine(idx + ":" + item.grade + "\t" + item.name);
            //        idx++;
            //    }
            //    Console.WriteLine();
            //    Console.WriteLine(sl.Count);
            //    for (int i = (sl.Count - 1); i >= 0; i--)
            //    {
            //        if (sl[i].grade > 1)
            //        {
            //            Console.WriteLine(i + ":" + sl[i].grade + "\t" + sl[i].name);
            //            sl.RemoveAt(i);
            //            //sl.Remove(sl[i]);
            //        }
            //    }
            //    Console.WriteLine();
            //    Console.WriteLine(sl.Count);
            //    foreach (var item in sl)
            //    {
            //        Console.WriteLine(item.grade + "\t" + item.name);
            //    }
            //    Console.WriteLine();
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Console.Clear();
            //    Random rnd = new Random();
            //    //Console.WriteLine(rnd.Next(10, 100));
            //    int r = rnd.Next(10, 100);
            //    Console.WriteLine(r);
            //    int i = -1;
            //    int tt = 8;
            //    int t = 0;
            //    bool g = false;
            //    while (r != i && t < tt)
            //    {
            //        Console.Write("input number (10~99) in " + (tt - t) + " times :");
            //        t++;
            //        try
            //        {
            //            i = int.Parse(Console.ReadLine());
            //        }
            //        catch (Exception)
            //        {
            //            break;
            //        }
            //        int c = ((i - r) == 0 ? 0 : (i - r) > 0 ? 1 : -1);
            //        UpDown ud = (UpDown)Enum.Parse(typeof(UpDown), ((i - r) == 0 ? 0 : (i - r) > 0 ? 1 : -1).ToString());
            //        switch (ud)
            //        {
            //            case UpDown.IDLE:
            //                g = true;
            //                break;
            //            case UpDown.UP:
            //            //g = false;
            //            //break;
            //            case UpDown.DOWN:
            //            //g = false;
            //            //break;
            //            default:
            //                g = false;
            //                break;
            //        }
            //        if (g)
            //        {
            //            Console.WriteLine("!!!Congraturation!!! " + "input number is " + i + "(" + c + ")" + ". guess number is " + r);
            //            //Console.ReadLine();
            //            break;
            //        }
            //        else
            //        {
            //            Console.WriteLine("!!!Try Again !!! " + "input number is " + ud + "(" + c + ")" + ". remain times is " + (tt - t));
            //            //Console.ReadLine();
            //            continue;
            //        }
            //        Console.WriteLine();
            //    }
            //    if ((tt - t) == 0)
            //    {
            //        Console.WriteLine("!!!Try Time is UP!!! "/* + "input number is " + ud*/ + ". guess number is " + r);
            //    }
            //    Console.WriteLine();
            //    Console.Write("To continue hit any key");
            //    Console.ReadLine();
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Test tt = new Test();
            //    Console.WriteLine("19^2 = " + tt.Power(19));
            //    Console.WriteLine("20^2 = " + tt.Power(20));
            //    Console.WriteLine("10*20 = " + tt.Multi(10, 20));
            //    Console.WriteLine("30*40 = " + tt.Multi(30, 40));
            //    Console.WriteLine("1...10 = " + tt.Sum(1, 10));
            //    Console.WriteLine(iTest);
            //    tt.Message("Hell, World!!!");
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Console.WriteLine(MyMath.Abs(10));
            //    Console.WriteLine(MyMath.Abs(-10));
            //    Console.WriteLine(MyMath.Abs(10.1234));
            //    Console.WriteLine(MyMath.Abs(-10.1234));
            //    Console.WriteLine(MyMath.Abs(12345678901234567890L));
            //    Console.WriteLine(MyMath.Abs(-1234567890123456789L));
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Product pr1 = new Product("Potato", 1000);
            //    //pr1.name = "Potato";
            //    //pr1.price = 1000;
            //    Console.WriteLine("pr1:" + pr1);
            //    Product pr2 = new Product("Tomato", 2000);
            //    Console.WriteLine("pr2:" + pr2);
            //    Product pr3 = new Product("Apple", 3000);
            //    Console.WriteLine("pr3:" + pr3);
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Sample dst = new Sample(8888);
            //    //Console.WriteLine(dst);
            //    Sample sa1 = new Sample("Potato", 1000);
            //    //sa1.name = "Potato";
            //    //sa1.saice = 1000;
            //    //Console.WriteLine("sa1:" + sa1);
            //    Sample sa2 = new Sample("Tomato", 2000);
            //    //Console.WriteLine("sa2:" + sa2);
            //    Sample sa3 = new Sample("Apple", 3000);
            //    //Console.WriteLine("sa3:" + sa3);
            //    //Delete dst;
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Box<int> b1 = new Box<int>(10, 10);
            //    Console.Write("input width:");
            //    b1.W = int.Parse(Console.ReadLine());
            //    Console.Write("input height:");
            //    b1.H = int.Parse(Console.ReadLine());
            //    Console.Write("input Height:");
            //    b1.Height = int.Parse(Console.ReadLine());
            //    Console.WriteLine("Height is:" + b1.Height);
            //    Console.WriteLine("Box area is:" + b1.Area());
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Int32 a = new Int32();
            //    Int32 b = a;
            //    b.m_value = 100;
            //    Console.WriteLine("a:" + a);
            //    Console.WriteLine("b:" + b);
            //    Test tt = new Test();
            //    Test ttt = tt;
            //    tt.Value = 10;
            //    ttt.Value = 20;
            //    Console.WriteLine(ttt.Value);
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Fibonacci.Fast = true;
            //    Console.Write("input true(1:default) or false(0):"/* + Fibonacci.Fast*/);
            //    try
            //    {
            //        Fibonacci.Fast = bool.Parse(int.Parse(Console.ReadLine()) == 1 ? "true" : "false");

            //    }
            //    catch (Exception)
            //    {
            //    }
            //    Console.WriteLine(Fibonacci.Fast);
            //    Fibonacci.Max = 50;
            //    Console.Write("input max number" + "(" + Fibonacci.Max + ":default)" + ":"/* + Fibonacci.Fast*/);
            //    try
            //    {
            //        Fibonacci.Max = int.Parse(Console.ReadLine());

            //    }
            //    catch (Exception)
            //    {
            //    }
            //    Console.WriteLine(Fibonacci.Max);
            //    Console.WriteLine();
            //    st = DateTime.Now;
            //    Console.WriteLine("Fibonacci.Get(0):" + Fibonacci.Get(0));
            //    Console.WriteLine("Fibonacci.Get(1):" + Fibonacci.Get(1));
            //    Console.WriteLine("Fibonacci.Get(10):" + Fibonacci.Get(10));
            //    Console.WriteLine("Fibonacci.Get(" + Fibonacci.Max + "):" + Fibonacci.Get());
            //    et = DateTime.Now;
            //    Console.WriteLine("Time elapsed: {0} ms", (et - st).TotalMilliseconds);
            //    Console.WriteLine();
            //    Console.WriteLine();
            //    //break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    //List<Dog> ds = new List<Dog>() { new Dog(), new Dog(), new Dog(), };
            //    //List<Cat> cs = new List<Cat>() { new Cat(), new Cat(), new Cat(), };
            //    List<Dog> ds = new List<Dog>() { new Dog("Dog1"), new Shephard("SDog1"), /*new Dog("Dog2"), new Dog("Dog3"), */};
            //    List<Cat> cs = new List<Cat>() { new Cat("Cat1"), new Persian("PCat1"), /*new Cat("Cat2"), new Cat("Cat3"), */};
            //    List<Pet> ps = new List<Pet>();
            //    ps.AddRange(ds);
            //    ps.AddRange(cs);
            //    Console.WriteLine();
            //    int num = 0;
            //    foreach (var item in ps)
            //    {
            //        num++;
            //        item.num = num;
            //        Console.WriteLine("" + item + ":" + item.num + "/" + Pet.count);
            //        Console.Write("item.Eat()\t"); item.Eat();
            //        Console.Write("(Pet)item).Eat()\t"); ((Pet)item).Eat();
            //        Console.Write("item.Sleep()\t"); item.Sleep();
            //        Console.Write("(Pet)item).Sleep()\t"); ((Pet)item).Sleep();
            //        Console.Write("item.Fuck()\t"); item.Fuck();
            //        Console.Write("(Pet)item).Fuck()\t"); ((Pet)item).Fuck();
            //        Console.Write("item.Die()\t"); item.Die();
            //        Console.Write("(Pet)item).Die()\t"); ((Pet)item).Die();
            //        var d = item as Dog;
            //        if (d != null) { Console.Write("d.Eat()\t"); d.Eat(); Console.Write("d.Bark()\t"); d.Bark(); }
            //        var c = item as Cat;
            //        if (c != null) { Console.Write("c.Eat()\t"); c.Eat(); Console.Write("c.Meow()\t"); c.Meow(); }
            //        //if (/*item.GetType() == typeof(Dog) && */item is Dog)
            //        //{
            //        //    ((Dog)item).Bark();
            //        //}
            //        //else if (/*item.GetType() == typeof(Cat) && */item is Cat)
            //        //{
            //        //    ((Cat)item).Meow();
            //        //}
            //        //var d = item as Dog;
            //        //if (d != null) { d.Bark(); }
            //        //var c = item as Cat;
            //        //if (c != null) { c.Meow(); }
            //        Console.WriteLine();
            //    }
            //    Console.WriteLine();
            //    //Dog d1 = new Dog();
            //    ////Dog d2 = new Dog(10);
            //    ////Dog d3 = new Dog("bitch");
            //    ////Console.WriteLine();
            //    ////Console.WriteLine(d1.num);
            //    ////Console.WriteLine(((Pet)d1).num);
            //    ////if (d1 is Dog) Console.WriteLine("Dog1");
            //    ////if ((Pet)d1 is Dog) Console.WriteLine("Dog2");
            //    ////if (((Pet)d1) is Dog) Console.WriteLine("Dog3");
            //    ////if (d1 is Pet) Console.WriteLine("Pet1");
            //    ////if ((Pet)d1 is Pet) Console.WriteLine("Pet2");
            //    ////if (((Pet)d1) is Pet) Console.WriteLine("Pet3");
            //    //d1.Eat();
            //    //((Pet)d1).Eat();
            //    //d1.Sleep();
            //    //((Pet)d1).Sleep();
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    //Generic<string> wString = new Generic<string>("abc");
            //    //Generic<int> wInt = new Generic<int>(123);
            //    //Generic<double> wDouble = new Generic<double>(3.14);
            //    //Console.WriteLine(wString.Value);
            //    //Console.WriteLine(wInt.Value);
            //    //Console.WriteLine(wDouble.Value);
            //    //Square<int> sqr = new Square<int>(10);
            //    //Console.WriteLine(sqr[10]);
            //    //Console.WriteLine(sqr[20]);
            //    //Console.WriteLine(sqr[30]);
            //    Product1<int> pr1 = new Product1<int>(10);
            //    //Console.WriteLine(pr1[10]);
            //    pr1[5] = 50;
            //    pr1[10] = 100;
            //    Console.WriteLine(pr1[10]);
            //    Console.WriteLine(pr1[5]);
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    int num;
            //    string s;
            //    Console.Write("input number in int:");
            //    s = Console.ReadLine();
            //    //num = int.Parse(Console.ReadLine());
            //    if (!int.TryParse(s, out num))
            //    {
            //        Console.WriteLine("input number :" + s  + " is NOT RIGHT. Please Try Again\n");
            //        continue;
            //    }
            //    Console.WriteLine("input number is:" + num + "\n");
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    int x = 0, y = 0, vx = 1, vy = 2;
            //    int rx, ry;
            //    Console.WriteLine("current pos is " + "(" + x + ", " + y + ")");
            //    NextPosition(x, y, vx, vy, out x, out y);
            //    Console.WriteLine("next pos is " + "(" + x + ", " + y + ")");
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    SPoint sp = new SPoint(2, 2);
            //    SPoint s1 = new SPoint();
            //    SPoint s2 = s1;
            //    CPoint cp = new CPoint(2, 2);
            //    CPoint c1 = new CPoint();
            //    CPoint c2 = c1;
            //    Console.WriteLine("sp:"/* + sp.GetHashCode() + "\t"*/ + sp.x + "," + sp.y);
            //    s2 = s1; s1.x = 1; s1.y = 1;
            //    Console.WriteLine("s1:"/* + s1.GetHashCode() + "\t"*/ + s1.x + "," + s1.y);
            //    Console.WriteLine("s2:"/* + s2.GetHashCode() + "\t"*/ + s2.x + "," + s2.y);
            //    Console.WriteLine();
            //    Console.WriteLine("cp:"/* + cp.GetHashCode() + "\t"*/ + cp.x + "," + cp.y);
            //    c2 = c1; c1.x = 1; c1.y = 1;
            //    Console.WriteLine("c1:"/* + c1.GetHashCode() + "\t"*/ + c1.x + "," + c1.y);
            //    Console.WriteLine("c2:"/* + c2.GetHashCode() + "\t"*/ + c2.x + "," + c2.y);
            //    Console.WriteLine();
            //    TheClass testClass = new TheClass();
            //    TheStruct testStruct = new TheStruct();
            //    testClass.willIChange = "Not Changed";
            //    testStruct.willIChange = "Not Changed";
            //    ClassTaker(testClass);
            //    StructTaker(testStruct);
            //    Console.WriteLine("Class field = {0}", testClass.willIChange);
            //    Console.WriteLine("Struct field = {0}", testStruct.willIChange);
            //    // Keep the console window open in debug mode.
            //    Console.WriteLine("Press any key to exit.");
            //    Console.ReadKey();
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    List<Product> lp = new List<Product>
            //    {
            //        new Product() {Name = "ProdE", Price = 100},
            //        new Product() {Name = "ProdD", Price = 200},
            //        new Product() {Name = "ProdC", Price = 300},
            //        new Product() {Name = "ProdB", Price = 500},
            //        new Product() {Name = "ProdA", Price = 400},
            //    };
            //    Console.WriteLine(nameof(lp) + "\t" + lp);
            //    foreach (var item in lp)
            //    {
            //        Console.WriteLine(nameof(item) + "\t" + item);
            //    }
            //    Console.WriteLine();
            //    lp.Sort();
            //    foreach (var item in lp)
            //    {
            //        Console.WriteLine(nameof(item) + "\t" + item);
            //    }
            //    Console.WriteLine();
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    string path = Directory.GetParent(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)).FullName;
            //    //Console.WriteLine(path);
            //    if (Environment.OSVersion.Version.Major >= 6)
            //    {
            //        path = Directory.GetParent(path).ToString();
            //        //Console.WriteLine(path);
            //    }
            //    //path += "\\Desktop\\.txt";
            //    //path += @"\Desktop";
            //    //path += @"\.txt";
            //    path = @".\.txt";
            //    Console.WriteLine(path);
            //    //File.WriteAllText(path, "FUCK\nFUCK\nFUCK\nFUCK");
            //    //Console.WriteLine(File.ReadAllText(path));
            //    // Get the directories currently on the C drive.
            //    DirectoryInfo[] cDirs = new DirectoryInfo(@"c:\").GetDirectories();
            //    // Write each directory name to a file. 
            //    using (StreamWriter sw = new StreamWriter("CDriveDirs.txt"))
            //    {
            //        //foreach (DirectoryInfo dir in cDirs)
            //        //{
            //        //    sw.WriteLine(dir.Name);
            //        //}
            //        sw.WriteLine("안녕");
            //        sw.WriteLine("안녕");
            //        sw.WriteLine("안녕");
            //        sw.WriteLine("안녕");
            //        sw.WriteLine("안녕");
            //        sw.WriteLine("안녕");
            //        sw.WriteLine("안녕");
            //        sw.WriteLine("안녕");
            //    }
            //    // Read and show each line from the file. 
            //    string line = "";
            //    using (StreamReader sr = new StreamReader("CDriveDirs.txt"))
            //    {
            //        while ((line = sr.ReadLine()) != null)
            //        {
            //            Console.WriteLine(line);
            //        }
            //    }
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    string[] a = { "", "", };
            //    Console.Write("input number in int:");
            //    string s = Console.ReadLine();
            //    int num;
            //    try
            //    {
            //        //int.TryParse(s, out num);
            //        num = int.Parse(s);
            //        Console.WriteLine("input number is " + num);
            //    }
            //    catch (Exception e)
            //    {
            //        Console.WriteLine("[CATCH]");
            //        Console.WriteLine(e.GetType() + ":" + e.HResult + ":" + e.Message);
            //        Console.WriteLine(e.StackTrace);
            //    }
            //    finally
            //    {
            //        Console.WriteLine("[FINALLY]");
            //    }
            //    Console.WriteLine("[CONTINUE]");
            //    Console.WriteLine();
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Box<int> b1 = new Box<int>(10, 10);
            //    Console.Write("input width:");
            //    try
            //    {
            //        b1.Width = int.Parse(Console.ReadLine());
            //    }
            //    catch (Exception e)
            //    {
            //        Console.WriteLine(e.GetType() + ":" + e.HResult + ":" + e.Message);
            //        Console.WriteLine(e.StackTrace + " \n");
            //        continue;
            //    }
            //    Console.Write("input height:");
            //    try
            //    {
            //        b1.Height = int.Parse(Console.ReadLine());
            //    }
            //    catch (Exception e)
            //    {
            //        Console.WriteLine(e.GetType() + ":" + e.HResult + ":" + e.Message);
            //        Console.WriteLine(e.StackTrace + " \n");
            //        continue;
            //    }
            //    Console.Write("Box's W/H is W:" + b1.Width + ", H:" + b1.Height + "\n");
            //    Console.WriteLine("Box's area is:" + b1.Area());
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    List<Product> lp = new List<Product>()
            //    {
            //        new Product() {Number = 5, Name = "Potato", Price = 400},
            //        new Product() {Number = 4, Name = "Tomato", Price = 500},
            //        new Product() {Number = 3, Name = "Banana", Price = 300},
            //        new Product() {Number = 2, Name = "Carrot", Price = 200},
            //        new Product() {Number = 1, Name = "Apple", Price = 100},
            //    };
            //    Console.WriteLine(nameof(lp) + "\t" + lp);
            //    lp.Sort();
            //    foreach (var item in lp)
            //    {
            //        Console.WriteLine(nameof(item) + "\t" + item);
            //    }
            //    Console.WriteLine();
            //    lp.Sort(Product.SortWithPrice);
            //    foreach (var item in lp)
            //    {
            //        Console.WriteLine(nameof(item) + "\t" + item);
            //    }
            //    Console.WriteLine();
            //    lp.Sort(Product.SortWithName);
            //    foreach (var item in lp)
            //    {
            //        Console.WriteLine(nameof(item) + "\t" + item);
            //    }
            //    Console.WriteLine();
            //    lp.Sort(delegate (Product a, Product b)
            //    {
            //        //return a.CompareTo(b);
            //        //return a.Price.CompareTo(b.Price);
            //        return a.Number.CompareTo(b.Number);
            //    });
            //    foreach (var item in lp)
            //    {
            //        Console.WriteLine(nameof(item) + "\t" + item);
            //    }
            //    Console.WriteLine();
            //    lp.Sort((a, b) =>
            //    {
            //        //return a.CompareTo(b);
            //        //return a.Price.CompareTo(b.Price);
            //        return a.Number.CompareTo(b.Number);
            //    });
            //    lp.Sort((a, b) => /*a.CompareTo(b)*//*a.Price.CompareTo(b.Price)*/a.Number.CompareTo(b.Number));
            //    foreach (var item in lp)
            //    {
            //        Console.WriteLine(nameof(item) + "\t" + item);
            //    }
            //    Console.WriteLine();
            //    lp.Sort((a, b) =>
            //    {
            //        return a.Number.CompareTo(b.Number);
            //    });
            //    foreach (var item in lp)
            //    {
            //        Console.WriteLine(nameof(item) + "\t" + item);
            //    }
            //    Console.WriteLine();
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Delegate1 d1 = Deleage1Method;
            //    Delegate1 d2 = delegate { };
            //    Delegate1 d3 = () => { };
            //    Delegate2 dele2 = Deleage2Method;
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    Students stds = new Students();
            //    stds.Add(new Student("윤인성", 4.2));
            //    stds.Add(new Student("연하진", 4.5));
            //    stds.Print();
            //    Console.WriteLine();
            //    stds.Print(delegate (Student std)
            //    {
            //        Console.Write(std.Name); Console.Write(":"); Console.Write(std.Score);
            //        Console.WriteLine();
            //    });
            //    Console.WriteLine();
            //    stds.Print((std) =>
            //    {
            //        Console.WriteLine(std.Name);
            //        Console.WriteLine(std.Score);
            //        Console.WriteLine();
            //    });
            //    Console.WriteLine();
            //    stds.Print(CPrintProcess.onPrintProcess);
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            //while (true)
            //{
            //    SendString sayHello, sayGoodbye, multiDelegate;
            //    sayHello = Hello;
            //    sayGoodbye = GoodBye;
            //    multiDelegate = sayHello + sayGoodbye;
            //    multiDelegate("john Doe");
            //    Console.WriteLine();
            //    multiDelegate -= sayGoodbye;
            //    multiDelegate("john Doe");
            //    Console.WriteLine();
            //    break;
            //}
            //Console.WriteLine("끝...\n");

            while (true)
            {
                //Thread th, th1, th2, th3;
                //th1 = new Thread(() =>
                //{
                //    for (int i = 0; i < 1000; i++)
                //    {
                //        Console.WriteLine("A");
                //    }
                //});
                //th2 = new Thread(() =>
                //{
                //    for (int i = 0; i < 1000; i++)
                //    {
                //        Console.WriteLine("B");
                //    }
                //});
                //th3 = new Thread(() =>
                //{
                //    for (int i = 0; i < 1000; i++)
                //    {
                //        Console.WriteLine("C");
                //    }
                //});
                //th1.Start();
                //th2.Start();
                //th3.Start();
                //th = new Thread(ExecuteInForeground);
                //th.Start();
                //Thread.Sleep(1000);
                //Console.WriteLine("Main thread ({0}) exiting...", Thread.CurrentThread.ManagedThreadId);
                DoWork();
                //ThreadPool.QueueUserWorkItem(ShowThreadInformation);
                //var th1 = new Thread(ShowThreadInformation);
                //th1.Start();
                //var th2 = new Thread(ShowThreadInformation);
                //th2.IsBackground = true;
                //th2.Start();
                //Thread.Sleep(500);
                //Console.WriteLine("Main thread ({0}) exiting...", Thread.CurrentThread.ManagedThreadId);
                //ShowThreadInformation(null);
                break;
            }
            //Console.WriteLine("끝...\n");
        }

        static Object obj = new Object();

        private static void ShowThreadInformation(Object state)
        {
            lock (obj)
            {
                var th = Thread.CurrentThread;
                Console.WriteLine("Managed thread #{0}: ", th.ManagedThreadId);
                Console.WriteLine("   Background thread: {0}", th.IsBackground);
                Console.WriteLine("   Thread pool thread: {0}", th.IsThreadPoolThread);
                Console.WriteLine("   Priority: {0}", th.Priority);
                Console.WriteLine("   Culture: {0}", th.CurrentCulture.Name);
                Console.WriteLine("   UI culture: {0}", th.CurrentUICulture.Name);
                Console.WriteLine();
            }
        }

        public static void DoWork()
        {
            // Queue a task.  
            System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(SomeLongTask));
            // Queue another task.  
            System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(AnotherLongTask));
        }

        private static void SomeLongTask(Object state)
        {
            // Insert code to perform a long task.  
            ExecuteInForeground();
        }

        private static void AnotherLongTask(Object state)
        {
            // Insert code to perform a long task.  
            ExecuteInForeground();
        }

        private static void ExecuteInForeground()
        {
            DateTime start = DateTime.Now;
            var sw = Stopwatch.StartNew();
            Console.WriteLine("Thread {0}: {1}, Priority {2}",
                              Thread.CurrentThread.ManagedThreadId,
                              Thread.CurrentThread.ThreadState,
                              Thread.CurrentThread.Priority);
            do
            {
                Console.WriteLine("Thread {0}: Elapsed {1:N2} seconds",
                                  Thread.CurrentThread.ManagedThreadId,
                                  sw.ElapsedMilliseconds / 1000.0);
                Thread.Sleep(500);
            } while (sw.ElapsedMilliseconds <= 5000);
            sw.Stop();
        }

        public delegate void SendString(string johndoe);

        public static void GoodBye(string johndoe)
        {
            Console.WriteLine("Good Bye " + johndoe);
        }

        public static void Hello(string johndoe)
        {
            Console.WriteLine("Hello " + johndoe);
        }

        public class CPrintProcess
        {
            public delegate void PrintProcess(Student std);

            private static void OnPrintProcess(Student std)
            {
                Console.WriteLine(std);
            }

            public static PrintProcess onPrintProcess = new PrintProcess(OnPrintProcess);
        }

        internal class Students
        {
            List<Student> ls = new List<Student>();

            public Students()
            {
            }

            internal void Add(Student std)
            {
                ls.Add(std);
            }

            internal void Print()
            {
                Print(CPrintProcess.onPrintProcess);
            }

            internal void Print(CPrintProcess.PrintProcess process)
            {
                foreach (var item in ls)
                {
                    process(item);
                }
            }
        }

        public class Student
        {
            public string name = null;
            public int grade = 0;
            public string Name { get; set; }
            public double Score { get; set; }

            public Student(string name, double score)
            {
                this.Name = name;
                this.Score = score;
            }

            public override string ToString()/* : this()*/
            {
                //return base.ToString();
                return /*MAGICSTUFF.GetInstanceName(this) + "\t" + */Name + ":" + Score;
            }
        }

        public delegate void Delegate1();
        static void Deleage1Method()
        {
            throw new NotImplementedException();
        }

        public delegate void Delegate2(String message);
        static void Deleage2Method(String message)
        {
            Console.WriteLine(message);
            throw new NotImplementedException();
        }

        public static int CompareNumber(Product l, Product r)
        {
            return l.Number.CompareTo(r.Number);
        }

        public static int SortWithPrice(Product l, Product r)
        {
            return l.Price.CompareTo(r.Price);
        }

        public static int SortWithName(Product l, Product r)
        {
            return l.Name.CompareTo(r.Name);
        }

        public class Product : IComparable
        {
            public static double pi = 3.14;
            public static int counter = 0;
            protected int id;
            private string name = null;
            private int price = 0;

            public Product()
            {
            }

            public Product(string name, int price)
            {
                Product.counter++;
                this.id = counter;
                this.name = name;
                this.price = price;
            }

            public int Number { get; set; }
            public string Name { get; set; }
            public int Price { get; set; }

            public int CompareTo(object obj)
            {
                //throw new NotImplementedException();
                //return this.Price - ((Product)obj).Price;
                //return this.Number.CompareTo(((Product)obj).Number);
                return this.Price.CompareTo(((Product)obj).Price);
                //return this.Name.CompareTo(((Product)obj).Name);
            }

            public static int CompareNumber(Product l, Product r)
            {
                return l.Number.CompareTo(r.Number);
            }

            public static int SortWithPrice(Product l, Product r)
            {
                return l.Price.CompareTo(r.Price);
            }

            public static int SortWithName(Product l, Product r)
            {
                return l.Name.CompareTo(r.Name);
            }

            public override string ToString()/* : this()*/
            {
                //return base.ToString();
                return /*MAGICSTUFF.GetInstanceName(this) + "\t" + */Number + ":" + Name + ":" + Price + "krw";
            }
        }

        class CustomException : Exception
        {
            public CustomException(string message) : base(message)
            {

            }
        }

        class Box<T>
        {
            //public int Width { get; set; }
            //public int Height { get; set; }
            private int width;

            public int Width
            {
                get { return width; }
                set
                {
                    if (value < 0)
                    {
                        throw new Exception("!!!Wrong!!! " + "Width:" + value);
                    }
                    width = value;
                }
            }

            private int height;

            public int Height
            {
                get { return height; }
                set
                {
                    if (value < 0)
                    {
                        throw new Exception("!!!Wrong!!! " + "Height:" + value);
                    }
                    height = value;
                }
            }

            //public Box(T w, T h)
            //{
            //}

            //public T Area()
            //{
            //    return (T)(w * h);
            //}

            public Box(int w, int h)
            {
                if (w < 0 || h < 0)
                {
                    Console.WriteLine("!!!Wrong!!! " + "w:" + w + "h:" + h);
                    return;
                }
                this.Width = w;
                this.Height = h;
            }

            public int Area()
            {
                return (Width * Height);
            }
        }

        void ReadFile(int index)
        {
            // To run this code, substitute a valid path from your local machine
            string path = @"c:\users\public\test.txt";
            System.IO.StreamReader file = new System.IO.StreamReader(path);
            char[] buffer = new char[10];
            try
            {
                file.ReadBlock(buffer, index, buffer.Length);
            }
            catch (System.IO.IOException e)
            {
                Console.WriteLine("Error reading from {0}. Message = {1}", path, e.Message);
            }
            finally
            {
                if (file != null)
                {
                    file.Close();
                }
            }
            // Do something with buffer...
        }

        class TestInterfaceClass : Interface1, Interface2, Interface3
        {
            public int TestProperty { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

            public int TestInstanceMethod()
            {
                throw new NotImplementedException();
            }
        }

        interface Interface3 : Interface1
        {
            int TestInstanceMethod();
            int TestProperty { get; set; }
        }

        class TheClass
        {
            public string willIChange;
        }

        struct TheStruct
        {
            public string willIChange;
        }

        static void ClassTaker(TheClass c)
        {
            c.willIChange = "Changed";
        }

        static void StructTaker(TheStruct s)
        {
            s.willIChange = "Changed";
        }

        private static void NextPosition(int x, int y, int vx, int vy, out int rx, out int ry)
        {
            rx = x + vx;
            ry = y + vy;
        }

        public static int iTest = 0;

        private static void Change(Test tt)
        {
            tt.Value = 10;
            throw new NotImplementedException();
        }

    }

    struct SPoint
    {
        public int x/* = 0*/;
        public int y/* = 0*/;

        public SPoint(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
    }

    class CPoint
    {
        public int x;
        public int y;

        public CPoint(int x = 0, int y = 0)
        {
            this.x = x;
            this.y = y;
        }
    }

    class Product1<T>
    {
        private int value;

        public Product1(int v)
        {
            this.value = v;
        }

        //public int this[T i]
        //{
        //    get
        //    {
        //        return i * i;
        //    }
        //}

        public int this[int i]
        {
            get
            {
                return this.value;
            }

            set
            {
                this.value = value;
            }
        }
    }

    class Square<T>
    {
        private int v;

        public Square(int v)
        {
            this.v = v;
        }

        //public int this[T i]
        //{
        //    get
        //    {
        //        return i * i;
        //    }
        //}

        public int this[int i]
        {
            get
            {
                return i * i;
            }
        }
    }

    class Generic2<T, U> where T : class where U : struct
    {
        public T Value1;
        public U Value2;
        public Generic2(T t, U u)
        {
            this.Value1 = t;
            this.Value2 = u;
        }
    }

    class Generic<T>
    {
        public T Value;
        public Generic(T t)
        {
            this.Value = t;
        }
    }

    abstract class Pet
    {
        public static int count = 0;

        public int num = 0;
        public string Name { get; set; }
        public int Age { get; set; }
        public string Color { get; set; }

        public Pet()
        {
            count++;
            Console.WriteLine("Pet()");
        }

        public Pet(String name) : this()
        {
            this.Name = name;
            Console.WriteLine("Pet(...), " + name + "\t" + this);
        }

        public Pet(int age) : this()
        {
            this.Age = age;
            Console.WriteLine("Pet(...), " + age + "\t" + this);
        }

        public override string ToString() { return (!string.IsNullOrEmpty(Name) ? Name : this.GetType().ToString()); }

        public void Born() { Console.WriteLine("HellHell"); }
        public virtual void Eat() { Console.WriteLine("YumYum"); }
        public virtual void Sleep() { Console.WriteLine("ZzzZzz"); }
        public virtual void Fuck() { Console.WriteLine("FuckFuck"); }
        public abstract void Die();/* { Console.WriteLine("DeadDead"); }*/
    }

    class Dog : Pet
    {
        /*public int num = 10;*/

        public Dog()
        {
            Console.WriteLine("Dog()");
        }

        public Dog(string name) : base(name)
        {
            Console.WriteLine("Dog(...), " + name);
        }

        public Dog(int age) : base(age)
        {
            Console.WriteLine("Dog(...), " + age);
        }

        public Dog(string name, int age) : base(name)/*, base(age)*/
        {
            Console.WriteLine("Dog(...), " + name + ", " + age);
        }

        public void Eat() { /*base.Eat(); */Console.WriteLine("D:Yum!Yum!"); }
        public void Sleep() { /*base.Sleep(); */Console.WriteLine("D:Zzz!Zzz!"); }
        sealed public override void Fuck() { Console.WriteLine("D:Fuck!Fuck!"); }
        public override void Die() { Console.WriteLine("D:Dead!Dead!"); }

        public void Bark() { Console.WriteLine("BOWWOW"); }
    }

    class Shephard : Dog
    {
        public Shephard(string name) : base(name)
        {
            Console.WriteLine("Shephard(...), " + name);
        }

        public void Eat() { /*base.Eat(); */Console.WriteLine("S:Yum!Yum!"); }
        public void Sleep() { /*base.Sleep(); */Console.WriteLine("S:Zzz!Zzz!"); }
        //public override void Fuck() { Console.WriteLine("S:Fuck!Fuck!"); }
    }

    class Cat : Pet
    {
        public Cat()/* : base()*/
        {
            Console.WriteLine("Cat()");
        }

        public Cat(string name)/* : base(name)*/
        {
            Console.WriteLine("Cat(...), " + name);
        }

        public Cat(int age)/* : base(age)*/
        {
            Console.WriteLine("Cat(...), " + age);
        }

        public Cat(string name, int age)/* : base(name)*//*, base(age)*/
        {
            Console.WriteLine("Cat(...), " + name + ", " + age);
        }

        public override void Eat() { /*base.Eat(); */Console.WriteLine("C:Yum!Yum!"); }
        public override void Sleep() { /*base.Sleep(); */Console.WriteLine("C:Zzz!Zzz!"); }
        sealed public override void Fuck() { Console.WriteLine("C:Fuck!Fuck!"); }
        public override void Die() { Console.WriteLine("C:Dead!Dead!"); }

        public void Meow() { Console.WriteLine("MIAOW"); }
    }

    class Persian : Cat
    {
        public Persian(string name) : base(name)
        {
            Console.WriteLine("Persian(...), " + name);
        }

        public override void Eat() { /*base.Eat(); */Console.WriteLine("P:Yum!Yum!"); }
        public override void Sleep() { /*base.Sleep(); */Console.WriteLine("P:Zzz!Zzz!"); }
        //sealed public override void Fuck() { Console.WriteLine("P:Fuck!Fuck!"); }
    }

    class Fibonacci
    {
        public static bool Fast { get; set; }
        public static int Max { get; set; }

        private static Dictionary<int, long> memo = new Dictionary<int, long>();
        public static long Get(int n)
        {
            if (n <= 0) return 0;
            if (n == 1) return 1;
            if (Fast)
            {
                if (memo.ContainsKey(n)) return memo[n];
                else
                {
                    long v = Get(n - 1) + Get(n - 2);
                    memo[n] = v;
                    return v;
                }
            }
            else
            {
                return Get(n - 1) + Get(n - 2);
            }
        }

        internal static long Get()
        {
            return Get(Max);
            throw new NotImplementedException();
        }
    }

    class Sample
    {
        public static double pi = 3.14;
        public readonly int id = 1234;
        public const int ie = 1234;
        static int count;

        public Sample()
        {
            count++;
            Console.WriteLine("Sample()" + this + ":" + count);
        }

        public Sample(int id)
        {
            this.id = id;
            Console.WriteLine("Sample(...)" + this + ":" + this.id);
        }

        public Sample(string name, int price)
        {
            Console.WriteLine("Sample(...)" + this + ":" + name + "," + price);
        }

        ~Sample()
        {
            Console.WriteLine("~Sample()" + this);
        }
    }
    class MyMath
    {
        //public static T Abs<T>(T x)
        //{
        //    if (x < 0) return -x; else return x;
        //    return x;
        //}

        public static int Abs(int x)
        {
            if (x < 0) return -x; else return x;
        }

        public static double Abs(double x)
        {
            if (x < 0) return -x; else return x;
        }

        public static long Abs(long x)
        {
            if (x < 0) return -x; else return x;
        }
    }

    class Test
    {
        public int Value { get; set; }

        public int Power(int x)
        {
            return (int)Math.Pow(x, 2);
        }

        public int Multi(int x, int y)
        {
            return x * y;
        }

        internal int Sum(int x, int y)
        {
            int ret = 0;
            for (int i = x; i <= y; i++)
            {
                ret += i;
            }
            return ret;
            throw new NotImplementedException();
        }

        internal void Message(String s)
        {
            Console.WriteLine(s);
        }
    }

    internal class Class2
    {
        public Class2()
        {
        }
    }
}

#include <iostream>
#include <time.h>
#include <vector>
#include <string>
#include <math.h>
using namespace std;

class Number
{
public:
	Number();
	Number(int n) { this->n = n; this->d = (double)n; };
	//Number(int n, double d) { this->n = n; this->d = d; };
	~Number();

	operator int() { return n; }
	operator double() { return d; }

	Number operator+(const Number  &r) { return Number(this->n + r.n); };
	bool operator==(const Number  &r) { return (this->n == r.n); };
	/*template <class T>*/ Number operator++();
	/*template <class T>*/ Number operator++(int i);
	/*template <class T>*/ Number operator--();
	/*template <class T>*/ Number operator--(int i);

	string toString() { return "" + this->n; }

private:
	int n = 0;
	double d = 0.0f;

};

Number::Number()
{
}

Number::~Number()
{
}

/*template <class T>*/
Number Number::operator++()
{
	this->n++;
	this->d = (double)n;
	return *this;
}

/*template <class T>*/
Number Number::operator++(int i)
{
	Number tmp(*this);
	operator++();
	return tmp;
}

/*template <class T>*/
Number Number::operator--()
{
	this->n--;
	this->d = (double)n;
	return *this;
}

/*template <class T>*/
Number Number::operator--(int i)
{
	Number tmp(*this);
	operator--();
	return tmp;
}

class Point
{
public:
	Point();
	~Point();

	Point(int x, int y) { this->x = x; this->y = y; }
	void show() { wcout << L"(x:" << x << L", y:" << y << L")\n"; }
	void setX(int x) { this->x = x; }
	void setY(int y) { this->y = y; }
	Point operator+(const int &r) { return Point(this->x + r, this->y + r); };
	Point operator+(const Point  &r) { return Point(this->x + r.x, this->y + r.y); };
	bool operator==(const Point  &r) { return (this->x == r.x && this->y == r.y); };
	Point operator++();
	Point operator++(int i);

	friend Point operator+(const int &l, const Point &r);
	friend Point operator+(const Point &l, const int &r);
	friend Point operator+(const Point &l, const Point &r);

private:
	int x;
	int y;
};

//int operator+(int &l, int &r) {
//	return (l + r) * 3;
//}

Point::Point()
{
}

Point::~Point()
{
}

Point Point::operator++()
{
	this->x++;
	this->y++;
	return *this;
}

Point Point::operator++(int c)
{
	Point tmp(*this);
	operator++();
	return tmp;
}

//Point Point::operator+(const Point &r)
//{
//	//Point p;
//	//p.x = this->x + r.x;
//	//p.y = this->y + r.y;
//	//return p;
//	return Point(this->x + r.x, this->y + r.y);
//}
//
//Point Point::operator+(const int &r)
//{
//	//Point p;
//	//p.x = this->x + r;
//	//p.y = this->y + r;
//	//return p;
//	return Point(this->x + r, this->y + r);
//}

/*Point operator+(const int &l, const Point &r);*/
/*Point operator+(const Point &l, const int &r);*/
/*Point operator+(const Point &l, const Point &r);*/

Point operator+(const int &l, const Point &r)
{
	Point p;
	p.x = l + r.x;
	p.y = l + r.y;
	return p;
}

Point operator+(const Point &l, const int &r)
{
	Point p;
	p.x = r + l.x;
	p.y = r + l.y;
	return p;
}

Point operator+(const Point & l, const Point & r)
{
	Point p;
	p.x = l.x + r.x;
	p.y = l.y + r.y;
	return p;
}

class Vehicle
{
protected:
	int speed;

public:
	Vehicle();
	~Vehicle();

	virtual void show() = 0;
	virtual void setSpeed(int speed);

private:
};

Vehicle::Vehicle()
{
	//speed = 0;
}

Vehicle::~Vehicle()
{
}

void Vehicle::show()
{
}

void Vehicle::setSpeed(int speed)
{
	this->speed = speed;
}

class Plane : public virtual Vehicle
{
public:
	Plane();
	Plane(int flight);
	Plane(int flight, int speed);
	~Plane();

	void show();

private:
	int flight;
};

Plane::Plane()
{
}

Plane::Plane(int flight)
{
	this->flight = flight;
}

Plane::Plane(int flight, int speed) : Plane(flight)
{
	this->speed = speed;
}

Plane::~Plane()
{
}

void Plane::show()
{
	wcout << this << L" plane no." << this->flight << L"'s speed is " << this->speed << L" kph.\n";
}

class Car : public virtual Vehicle
{
private:
	char *name = "";
	static int csum;

protected:
	int num;
	double gas;

public:
	Car();
	Car(const Car &r);
	Car(int num/* = 0*/, double gas/* = 0.0*/);
	Car(int num, double gas, int speed);
	Car(int num, double gas, int speed, char *name);
	~Car();

	void show();
	static void showSum();
	void setNumGas(int num, double gas);
	int getNum() { return num; }
	double getGas() { return gas; }
	char *getName() { return name; }
	//Car &operator=(const Car &r) { return *new Car(r); }
	Car &operator=(const Car &r) /*{ return *new Car(r.num, r.gas, r.speed, const_cast<char*>(string("copy2 of " + string(r.name)).c_str())); }*/;

};

Car::Car(const Car &r)
{
	this->num = r.num;
	this->gas = r.gas;
	this->speed = r.speed;
	this->name = new char[strlen("copy1 of ") + strlen(r.name) + 1];
	strcpy_s(this->name, strlen("copy1 of ") + 1, ("copy1 of "));
	strcat_s(this->name, strlen("copy1 of ") + strlen(r.name) + 1, r.name);
	//this->name = const_cast<char*>(string("copy1 of " + string(r.name)).c_str());
	wcout << this << L" car no." << this->num << L" '" << this->name << L"' is copyed.\n";
}

Car & Car::operator=(const Car &r)
{
	// TODO: insert return statement here
	if (this != &r)
	{
		if (strlen(this->name))
		{
			delete[] this->name;
		}
		this->num = r.num;
		this->gas = r.gas;
		this->speed = r.speed;
		this->name = new char[strlen("copy2 of ") + strlen(r.name) + 1];
		strcpy_s(this->name, strlen("copy2 of ") + 1, ("copy2 of "));
		strcat_s(this->name, strlen("copy2 of ") + strlen(r.name) + 1, r.name);
		//this->name = const_cast<char*>(string("copy2 of " + string(r.name)).c_str());
		wcout << this << L" car no." << this->num << L" '" << this->name << L"' is copyed.\n";
	}
	return *this;
}

Car::Car()
{
	this->name = "";
	//this->num = 0;
	//this->gas = 0.0;
	csum++;
}

Car::Car(int num, double gas) : Car()
{
	this->num = num;
	this->gas = gas;
}

Car::Car(int num, double gas, int speed) : Car(num, gas)
{
	this->speed = speed;
}

Car::Car(int num, double gas, int speed, char *name) : Car(num, gas, speed)
{
	this->name = new char[strlen(name) + 1];
	strcpy_s(this->name, strlen(name) + 1, name);
	wcout << this << L" car no." << this->num << L" '" << this->name << L"' is created.\n";
}

Car::~Car()
{
	wcout << this << L" car no." << this->num << L" '" << this->name << L"' is destroyed.\n";
	if (strlen(name))
	{
		delete[] name;
	}
}

void Car::show()
{
	wcout << this << L" car no." << this->num << L" '" << this->name << L"'s gas amount is " << this->gas << L" and speed is " << this->speed << L" kph.\n";
}

void Car::setNumGas(int num, double gas)
{
	this->num = num;
	this->gas = gas;
}

int Car::csum = 0;

void Car::showSum()
{
	wcout << L"only car " << csum << "'s is made" << L".\n";
}

class RaceCar : public Car, public Plane
{
	int course;
public:
	RaceCar();
	RaceCar(int num, double gas, int speed, int course);
	RaceCar(int num, double gas, int speed, int course, char *name);
	~RaceCar();
	void setCourse(int course);
	void show();
};

RaceCar::RaceCar()
{
}

RaceCar::RaceCar(int num, double gas, int speed, int course) : Car(num, gas, speed)
{
	this->course = course;
}

RaceCar::RaceCar(int num, double gas, int speed, int course, char *name) : Car(num, gas, speed, name)
{
	this->course = course;
	wcout << this << L" Rcar no." << this->num << L" '" << getName() << L"' is created.\n";
}

RaceCar::~RaceCar()
{
	wcout << this << L" Rcar no." << this->num << L" '" << getName() << L"' is destroyed.\n";
}

void RaceCar::setCourse(int course) {
	this->course = course;
}

void RaceCar::show()
{
	wcout << this << L" Rcar no." << this->num << L" '" << this->getName() << L"'s gas amount is " << this->gas << L" and speed is " << this->speed << L" kph." << L" in course no." << this->course << L".\n";
}

//bool buyCar(Car c)
//{
//	int n = c.getNum();
//	double g = c.getGas();
//	wcout << /*c. << */L"buy car no." << n << "'s gas amount is " << g << L".\n";
//	return true;
//}

bool buyCar(Car &c)
{
	int n = c.getNum();
	double g = c.getGas();
	wcout << /*c. << */L"buy car no." << n << "'s gas amount is " << g << L".\n";
	return true;
}

bool buyCar(Car *c)
{
	int n = c->getNum();
	double g = c->getGas();
	wcout << /*c. << */L"buy car no." << n << "'s gas amount is " << g << L".\n";
	return true;
}

//struct Car
//{
//	int num;
//	double gas;
//};
//
//void show(Car *c)
//{
//	wcout << L"car no." << c->num << "'s gas amount is " << c->gas << L".\n";
//	c->num *= 2;
//	c->gas *= 2;
//}
//
//void show(Car c)
//{
//	wcout << L"car no." << c.num << "'s gas amount is " << c.gas << L".\n";
//	c.num *= 2;
//	c.gas *= 2;
//}

//BC (�����) : ����� Before Christ �� ���� (�׸����� ź�� ����)
//AD (����/�����) : ��ƾ��� anno Domini (�ִ��� ��)�� �����Դϴ�.
union Year
{
	int ad;	// anno Domini
	int de;	// Dangun Era
};

enum Week
{
	SUN, MON, TUE, WED, THU, FRI, SAT
};

template<typename T, size_t SIZE>
size_t getSize(T(&)[SIZE]) {
	return SIZE;
}

template <unsigned N, typename T>
void foo(T(&p)[N]) {
	// p is a reference to an array[N] of T
	std::cout << "array has " << N << " elements" << std::endl;
	std::cout << "array has "
		<< sizeof(p) / sizeof(p[0])
		<< " elements"
		<< std::endl;
}

void buy(int x)
{
	wcout << L"Buy a car in " << x << L"0T.krw\n";
}

int buy(int x, int y)
{
	int ret = 0;

	wcout << L"Buy a 1st car in " << x << L"0T.krw\n";
	wcout << L"Buy a 2nd car in " << y << L"0T.krw\n";

	return ret = (x + y);
}

//int max(int x, int y)
//{
//	int ret = 0;
//
//	wcout << L"1st number is " << x << ".\n";
//	wcout << L"2nd number is " << y << ".\n";
//
//	return ret = (x > y) ? x : y;
//}
//
//double max(double x, double y)
//{
//	double ret = 0;
//
//	wcout << L"1st number is " << x << ".\n";
//	wcout << L"2nd number is " << y << ".\n";
//
//	return ret = (x > y) ? x : y;
//}

template <class T>	// <typename T>
T max(T x, T y)
{
	T ret = 0;

	wcout << L"1st number is " << x << ".\n";
	wcout << L"2nd number is " << y << ".\n";

	return ret = (x > y) ? x : y;
}

template <class T>	// <typename T>
T sqr(T x, T y)
{
	T ret = 0;

	wcout << L"1st 2 powered number is " << pow(x, 2.0) << ".\n";
	wcout << L"2nd 2 powered number is " << pow(y, 2.0) << ".\n";

	return ret = (T)pow(x, 2.0) + (T)pow(y, 2.0);
}

template <class T>	// <typename T>
void swp(T *x, T *y)
{
	T *tmp = new T();
	*tmp = *x;
	*x = *y;
	*y = *tmp;
}

template <class T>	// <typename T>
void swp(int &x, int &y)
{
	int tmp;
	tmp = x;
	x = y;
	y = tmp;
}

//template <class T>	// <typename T>
//T sum(T x, T y)
//{
//	T ret;
//	x += 50;
//	y += 50;
//	return ret = x + y;
//}

// Sum of Pass by Reference
template <class T>	// <typename T>
T sum(T &x, T &y)
{
	T ret;
	x += 50;
	y += 50;
	return ret = x + y;
}

// Sum of Call by Reference
template <class T>	// <typename T>
T sum(T *x, T *y)
{
	T ret;
	*x += 50;
	*y += 50;
	return ret = *x + *y;
}

//template <class T>	// <typename T>
//template <class U>	// <typename T>
//double avg(int a[])
//{
//	wcout << L"size of 'a' is " << sizeof(a) << L", size of '*a' is " << sizeof(*a) << L", '(sizeof(a) / sizeof(*a))' is " << (sizeof(a) / sizeof(a[0])) << L"\n";
//	double ret = 0, sum = 0;
//	for (int i = 0; i < (sizeof(a) / sizeof(*a)); i++)
//	{
//		sum += a[i];
//	}
//	return ret = sum / (sizeof(a) / sizeof(*a));
//}

//template <class T>	// <typename T>
//template <class U>	// <typename T>
double avg(int *a)
{
	wcout << L"size of 'a' is " << sizeof(a) << L", size of '*a' is " << sizeof(*a) << L", '(sizeof(a) / sizeof(*a))' is " << (sizeof(a) / sizeof(int)) << L"\n";
	double ret = 0, sum = 0;
	for (int i = 0; i < (sizeof(a) / sizeof(*a)); i++)
	{
		sum += a[i];
	}
	return ret = sum / (sizeof(a) / sizeof(*a));
}

int len(char *str)
{
	int ret = 0;
	while (str[ret])
	{
		ret++;
	}
	return ret;
}

int count(char str[], char ch)
{
	int i = 0;
	int c = 0;
	while (str[i])
	{
		if (str[i] == ch) c++;
		i++;
	}
	return c;
}

int a = 0;
int *func()
{
	int *ret;
	//int a = 0;
	int b = 0;
	static int c = 0;
	a++;
	b++;
	c++;
	ret = &a;
	wcout << L"'a' : " << a << L"\t\t'b' : " << b << L"\t\t'c' : " << c << L"\n";
	wcout << L"'&a': " << &a << L"\t'&b': " << &b << L"\t'&c': " << &c << L"\n";
	return ret;
}

int main()
{
	int res = 0;
	clock_t st = 0, et = 0;
	struct tm *tm = NULL;

	wcout << L"Hell, World!!!\n";
	/*wcout << L"����, ����!!!\n";*/
	setlocale(LC_ALL, "korean");
	_wsetlocale(LC_ALL, L"korean");
	wcout << L"����, ����!!!\n";
	wcout << L"sizeof('A'):" << sizeof('A') << L"\tsizeof(char):" << sizeof(char) << L"\n";
	wcout << L"sizeof(L'A'):" << sizeof(L'A') << L"\tsizeof(char):" << sizeof(char) << L"\n";
	wcout << L"sizeof(L'��'):" << sizeof(L'��') << L"\tsizeof(wchar_t):" << sizeof(wchar_t) << L"\n";
	wcout << L"\n";

	//wcout << L"hit any key to continue...";
	//cin >> res;

	//while (true)
	//{
	//	int num1;
	//	double num2;
	//	num1 = 3.14;
	//	num2 = 3.14;
	//	wcout << num1 << '\n';
	//	wcout << num2 << '\n';
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int num1, num2 = 0;
	//	wcout << "input:\n";
	//	cin >> num1 >> num2;
	//	wcout << "output:\n" << num1 << "\n" << num2 << "\n";
	//	wcout << L"��...\n\n";
	//	break;
	//}


	//while (true)
	//{
	//	static /*const */double pi = 3.141592;
	//	wcout << "Phi value is " << pi << ".\n";
	//	pi = 3.14;
	//	wcout << "Phi value is " << pi << ".\n";
	//	int num1 = 10, num2 = 20;
	//	wcout << "1 + 2 is " << 1 + 2 << ".\n";
	//	wcout << "input:\n";
	//	cin >> num1 >> num2;
	//	wcout << num1 << " + " << num2 << " is " << num1 + num2 << ".\n";
	//	break;
	//}
	//wcout << L"��...\n\n";


	//while (true)
	//{
	//	int num1 = 0, num2 = 0;
	//	wcout << num1 << " / " << num2 << " is " << num1 / num2 << ".\n";
	//	num2 = num1++;
	//	//num2 = ++num1;
	//	//num2 = num1++;
	//	//num2 = ++num1;
	//	wcout << "num1 is " << num1 << ".\n";
	//	wcout << "num2 is " << num2 << ".\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int sum = 0;
	//	int num = 0;
	//	//std::vector<int> v = { 0, 1, 2, 3, 4, 5 };
	//	//for (const int& i : v)
	//	for (int i = 0; i < 6; i++)
	//	{
	//		wcout << "no." << i + 1 << " input:";
	//		cin >> num;
	//		sum += num;
	//		wcout << "sum is " << sum << ".\n";
	//		wcout << "\n";
	//	}
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int a = 0, b = 0;
	//	char c = 'a';
	//	wchar_t d = L'��';
	//	wcout << "#### size of ####\n";
	//	wcout << "int size is " << sizeof(int) << "bytes.\n";
	//	wcout << "unsigned int size is " << sizeof(unsigned int) << "bytes.\n";
	//	wcout << "short size is " << sizeof(short) << "bytes.\n";
	//	wcout << "unsigned short size is " << sizeof(unsigned short) << "bytes.\n";
	//	wcout << "long size is " << sizeof(long) << "bytes.\n";
	//	wcout << "unsigned long size is " << sizeof(unsigned long) << "bytes.\n";
	//	wcout << "float size is " << sizeof(float) << "bytes.\n";
	//	wcout << "double size is " << sizeof(double) << "bytes.\n";
	//	wcout << L"\n";
	//	wcout << "int variable \'a\' size is " << sizeof(a) << "bytes.\n";
	//	wcout << "int variable \'a + b\' size is " << sizeof(a + b) << "bytes.\n";
	//	wcout << "char variable c:\'" << c << "\' size is " << sizeof(c) << "bytes.\n";
	//	wcout << "wchar_t variable d:\'" << d << "\' size is " << sizeof(d) << "bytes.\n";
	//	wcout << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//int _int = 273;
	//long _long = 1234567890123456789;
	//float _float = 0.1234567890123456789012345678901234567890123456789012345678901234567890f;
	//double _double = 1.1234567890123456789012345678901234567890123456789012345678901234567890f;
	//char _char = 'A';
	//wchar_t __char = L'��';
	//string _string = "1234567890abcdefghijklmnopqrstuvwxyz������������������������";
	//wcout << L"_int\t" << typeid(_int).name() << L"\t" << sizeof(_int) << L"\t" << _int << L"\n";
	//wcout << L"_long\t" << typeid(_long).name() << L"\t" << sizeof(_long) << L"\t" << _long << L"\n";
	//wcout << L"_float\t" << typeid(_float).name() << L"\t" << sizeof(_float) << L"\t" << _float << L"\n";
	//wcout << L"_double\t" << typeid(_double).name() << L"\t" << sizeof(_double) << L"\t" << _double << L"\n";
	//wcout << L"_char\t" << typeid(_char).name() << L"\t" << sizeof(_char) << L"\t" << _char << L"\n";
	//wcout << L"__char\t" << typeid(__char).name() << L"\t" << sizeof(__char) << L"\t" << __char << L"\n";
	//wcout << L"_string\t" << typeid(_string).name() /*<< L"\t" << (unsigned int)_string.length*/ << L"\t" << const_cast<char*>(_string.c_str()) << L"\n";
	//wcout << L"\n";
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	setlocale(LC_ALL, "korean");
	//	_wsetlocale(LC_ALL, L"korean");
	//	wchar_t *ws1 = L"hell, world!";    // ���̵� ���ڿ��� l�� ����
	//	wchar_t *ws2 = L"�ȳ��ϼ���.";
	//	wprintf(L"wchar_t * variable ws1:\'%s\' size is %dbytes.\n", ws1, sizeof(ws1));
	//	wprintf(L"wchar_t * variable ws2:\'%s\' size is %dbytes.\n", ws2, sizeof(ws2));
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int i_num = 160;
	//	double d_num = 160.5;
	//	wcout << "Height is " << d_num << "cm.\n";
	//	wcout << "put int val into double val.\n";
	//	d_num = i_num;
	//	wcout << "Height is " << d_num << "cm.\n\n";
	//	wcout << "Height is " << i_num << "cm.\n";
	//	wcout << "put double val into int val.\n";
	//	i_num = (double)d_num;
	//	wcout << "Height is " << i_num << "cm.\n\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int i_num = 2;
	//	double d_num = 3.14;
	//	wcout << "Radius is " << i_num << "cm.\n";
	//	wcout << "Round is " << i_num * 2 * d_num << "cm.\n";
	//	wcout << 50 / 20.0 << "\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int num1 = 5, num2 = 4;
	//	double d_num;
	//	d_num = (double)num1 / (double)num2;
	//	wcout << "5 devide 4 is " << d_num << "\n";
	//	d_num = (double)num1 / num2;
	//	wcout << "5 devide 4 is " << d_num << "\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	double w = 0.0, h = 0.0;
	//	double area = 0.0;
	//	wcout << "width(int):";
	//	cin >> w;
	//	wcout << "height(int):";
	//	cin >> h;
	//	area = (double)w * h / 2;
	//	wcout << L"\n";
	//	wcout << "triareagle arearearea is " << area;
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true) {
	//	int res;
	//	wcout << "������ �Է��ϼ���...:";
	//	//cin >> res;
	//	//if (cin.fail())
	//	if (!(cin >> res))
	//	{
	//		cin.clear();
	//		cin.ignore(10000, '\n');
	//		wcout << "������ �̶�ϱ��!!!\n";
	//		wcout << "\n";
	//		continue;
	//	}
	//	//if (res == 1)
	//	//{
	//	//	wcout << "1�� �Է� �Ǿ����ϴ�.\n";
	//	//}
	//	//else if (res == 2)
	//	//{
	//	//	wcout << "2�� �Է� �Ǿ����ϴ�.\n";
	//	//}
	//	//else 
	//	//{
	//	//	wcout << res << "��(��) �Է� �Ǿ����ϴ�.\n";
	//	//}
	//	switch (res)
	//	{
	//	case 1:
	//		wcout << "1�� �Է� �Ǿ����ϴ�.\n";
	//		break;
	//	case 2:
	//		wcout << "2�� �Է� �Ǿ����ϴ�.\n";
	//		break;
	//	default:
	//		wcout << res << "��(��) �Է� �Ǿ����ϴ�.\n";
	//		break;
	//	}
	//	wcout << "\n";
	//}
	////wcout << "ó���� �����մϴ�.\n";
	//wcout << L"��...\n\n";

	//while (true) {
	//	int mon;
	//	wcout << "�޼��� �Է��ϼ���...:";
	//	//cin >> mon;
	//	//if (cin.fail())
	//	if (!(cin >> mon))
	//	{
	//		cin.clear();
	//		cin.ignore(10000, '\n');
	//		wcout << "�޼��� �̶�ϱ��!!!\n";
	//		wcout << "\n";
	//		continue;
	//	}
	//	switch (mon)
	//	{
	//	case 3:
	//	case 4:
	//	case 5:
	//		wcout << "������!!! ���� �Գ׿�.\n";
	//		break;
	//	case 6:
	//	case 7:
	//	case 8:
	//		wcout << "������������!!! ������ �Գ׿�.\n";
	//		break;
	//	case 9:
	//	case 10:
	//	case 11:
	//		wcout << "������������!!! ������ �Գ׿�.\n";
	//		break;
	//	case 12:
	//	case 1:
	//	case 2:
	//		wcout << "�ܿ�ܿ�ܿ�!!! �ܿ��� �Գ׿�.\n";
	//		break;
	//	default:
	//		wcout << mon << "��(��) �Է� �Ǿ����ϴ�.\n";
	//		break;
	//	}
	//	wcout << "\n";
	//}
	////wcout << "ó���� �����մϴ�.\n";
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	char res;
	//	wcout << "�ʴ� �ѱ��� �Դϱ� [Y(y)/N(n)]? : ";
	//	cin >> res;
	//	if (res == 'Y' || res == 'y')
	//	{
	//		wcout << "�ѱ�!!!\n";
	//	}
	//	else if (res == 'N' || res == 'n')
	//	{
	//		wcout << "�ܱ�!!!\n";
	//	}
	//	else {
	//		wcout << "�ܰ�!!!\n";
	//	}
	//	wcout << "\n";
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int res;
	//	char ans;
	//	wcout << "��� �ڽ��� �ֹ��Ͻ÷���(����)?:";
	//	cin >> res;
	//	//3�� ������(���� ������) ���
	//	ans = (res == 1) ? 'A' : 'B';
	//	wcout << ans << " �ڽ��� �ֹ��ϼ̽���\n";
	//	wcout << "\n";
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	setlocale(LC_ALL, "korean");
	//	_wsetlocale(LC_ALL, L"korean");
	//	int res;
	//	wchar_t ans;
	//	wcout << L"���ڸ� �Է����ֻ�?:";
	//	//cin >> res;
	//	//if (cin.fail())
	//	if (!(cin >> res))
	//	{
	//		cin.clear();
	//		cin.ignore(10000, '\n');
	//		wcout << L"���ڸ� �̶�ϱ��!!!\n";
	//		wcout << "\n";
	//		continue;
	//	}
	//	//3�� ������(���� ������) ���
	//	ans = (res % 2 == 0) ? L'¦' : L'Ȧ';
	//	wcout << L"\'" << ans << L"\'" << L"����\n";
	//	wcout << L"\n";
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	std::vector<int> v = { 0, 1, 2, 3, 4, 5 };
	//	for (const int& i : v) // access by const reference
	//		std::wcout << i << ' ';
	//	std::wcout << '\n';
	//	for (auto i : v) // access by value, the type of i is int
	//		std::wcout << i << ' ';
	//	std::wcout << '\n';
	//	for (auto&& i : v) // access by reference, the type of i is int&
	//		std::wcout << i << ' ';
	//	std::wcout << '\n';
	//	for (int n : {0, 1, 2, 3, 4, 5}) // the initializer may be a braced-init-list
	//		std::wcout << n << ' ';
	//	std::wcout << '\n';
	//	int a[] = { 0, 1, 2, 3, 4, 5 };
	//	for (int n : a) // the initializer may be an array
	//		std::wcout << n << ' ';
	//	std::wcout << '\n';
	//	for (int n : a)
	//		std::wcout << 1 << ' '; // the loop variable need not be used
	//	std::wcout << '\n';
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	//for (int i = 0; i < 5; i++)
	//	//{
	//	//	wcout << L"i:" << i << "\n";
	//	//}
	//	//wcout << L"\n";
	//	//for (int i = 5; i <= 10; i++)
	//	//{
	//	//	wcout << L"i:" << i << "\n";
	//	//}
	//	//wcout << L"\n";
	//	//for (int i = 5; i >= 0; i--)
	//	//{
	//	//	wcout << L"i:" << i << "\n";
	//	//}
	//	//wcout << L"\n";
	//	//int num;
	//	//wcout << L"'*'�� � ������?:";
	//	//cin >> num;
	//	//for (int i = 0; i < num; i++)
	//	//{
	//	//	wcout << L"*\n";
	//	//}
	//	//wcout << L"\n";
	//	int num, fct = 0;
	//	wcout << L"input max number:";
	//	if (!(cin >> num))
	//	{
	//		cin.clear();
	//		cin.ignore(10000, '\n');
	//		wcout << L"���ڸ� �̶�ϱ��!!!\n";
	//		num = 999999999;
	//		wcout << num;
	//		wcout << L"\n";
	//		//continue;
	//	}
	//	//for (int i = 0; i < num; i++)
	//	//{
	//	//	fct += i + 1;
	//	//	if (i < num - 1)
	//	//	{
	//	//		wcout << i + 1 << L" + ";
	//	//	}
	//	//	else
	//	//	{
	//	//		wcout << i + 1 << L" = " << fct << "\n";
	//	//	}
	//	//}
	//	st = clock();
	//	int i = 0;
	//	while (i < num)
	//	{
	//		fct += i + 1;
	//		if (i < num - 1)
	//		{
	//			wcout << i + 1 << L" + ";
	//		}
	//		else
	//		{
	//			wcout << i + 1 << L" = " << fct << "\n";
	//		}
	//		i++;
	//	}
	//	et = clock();
	//	wcout << L"factorial value from 1 to " << num << " is " << fct;
	//	wcout << L"\n";
	//	wcout << L"estimated time(msec):" << float(et - st);
	//	wcout << L"\n";
	//	wcout << L"\n";
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int i = 0;
	//	do
	//	{
	//		wcout << L"Input integer.(if '0', will terminate):";
	//		cin >> i;
	//		wcout << L"Input number is " << i;
	//		wcout << L"\n";
	//	} while (i);
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	for (int i = 0; i < 5; i++)
	//	{
	//		for (int j = 0; j < 3; j++)
	//		{
	//			wcout << L"index i:" << i << L", j:" << j << L"\n";
	//		}
	//	}
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int ch = 0;
	//	for (int i = 0; i < 5; i++)
	//	{
	//		for (int j = 0; j < 5; j++)
	//		{
	//			for (int k = 0; k < 1; k++)
	//			{
	//				wcout << L"index i:" << i << L", j:" << j << L", k:" << k << L"\t" << L"ch:" << ch << L"\t";
	//				//if (ch == 0)
	//				//{
	//				//	wcout << L'*';
	//				//	ch = 1;
	//				//}
	//				//else
	//				//{
	//				//	wcout << L'-';
	//				//	ch = 0;
	//				//}
	//				(ch == 0) ? wcout << L'*' : wcout << L'-';
	//				(ch == 0) ? ch = 1 : ch = 0;
	//				//(ch % 2 == 0) ? wcout << L'*' : wcout << L'-';
	//				//ch++;
	//				wcout << L"\n";
	//			}
	//		}
	//	}
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int res, l = 0;
	//	wcout << L"How many times do you want?\n";
	//	cin >> res;
	//	for (int i = 0; i < 100; i++)
	//	{
	//		for (int j = 0; j < res + 1; j++)
	//		{
	//			for (int k = 0; k < 1; k++)
	//			{
	//				wcout << L"len l:" << l + 1 << L", index i:" << i << L", j:" << j << L", k:" << k << L"\t" << L"res:" << res << L"\t";
	//				wcout << L"time(s) : " << j + 1 << L"\n";
	//				//if (j == res - 1) break;
	//				l++;
	//			}
	//		}
	//	}
	//	wcout << L"\n";
	//	wcout << L"\n";
	//	for (int i = 1; i <= 10; i++)
	//	{
	//		if (i == res) continue;
	//		wcout << L"time(s) : " << i << L"\n";
	//	}
	//	break;
	//}
	//wcout << L"��...\n\n";

	res = 0;
	while (res < 27)
	{
		res++;
		int c, d;
		wcout << L"Input integer.(if '0', will terminate):";
		//cin >> res;
		wcout << L"Input number is " << res << L"\n";
		wcout << L"\n";
		//(1)
		wcout << L"(1)\n";
		c = 1;
		for (int i = 0; i < res; i++)
		{
			wcout << L"line(s) : " << i + 1 << L"\t\t";
			for (int j = 0; j < c; j++)
			{
				wcout << '*';
			}
			c++;
			wcout << L"\n";
		}
		wcout << L"\n";
		//(2)
		wcout << L"(2)\n";
		c = res;
		for (int i = 0; i < res; i++)
		{
			wcout << L"line(s) : " << i + 1 << L"\t\t";
			for (int j = 0; j < res; j++)
			{
				(j >= c - 1) ? wcout << '*' : wcout << ' ';
			}
			c--;
			wcout << L"\n";
		}
		wcout << L"\n";
		//(3)
		//wcout << L"(3)\n";
		//c = d = res;
		//for (int i = 0; i < res; i++)
		//{
		//	//wcout << L"line(s) : " << i + 1 << L"\t\t";
		//	for (int j = 0; j < res * 2; j++)
		//	{
		//		((j >= c - 1 && j < d) || false) ? wcout << '*' : wcout << ' ';
		//	}
		//	c--;
		//	d++;
		//	wcout << L"\n";
		//}
		//wcout << L"\n";
		wcout << L"(3)\n";
		for (int i = 1; i <= res; i++)
		{
			wcout << L"line(s) : " << i << L"\t\t";
			for (int j = res; j > i; j--)
			{
				wcout << ' ';
			}
			for (int j = 0; j < 2 * i - 1; j++)
			{
				wcout << '*';
			}
			wcout << L"\n";
		}
		//wcout << L"\n";
		//(4)
		wcout << L"(4)\n";
		c = d = res;
		for (int i = 0; i < res * 2 - 1; i++)
		{
			//wcout << L"line(s) : " << i + 1 << ", c:" << c << ", d:" << d << L"\t\t";
			wcout << L"line(s) : " << i + 1 << L"\t\t";
			for (int j = 0; j < res * 2; j++)
			{
				((i < res && (j > c - 2 && j < d)) || (i > res - 1 && (j > -c && j < (res * 2 + c) - 2))) ? wcout << '*' : wcout << ' ';
			}
			c--;
			d++;
			wcout << L"\n";
		}
		wcout << L"\n";
	}

	//while (true)
	//{
	//	int num;
	//	wcout << L"input car price(s):";
	//	cin >> num;
	//	buy(num);
	//	wcout << L"\n";
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int num1, num2;
	//	wcout << L"input 1st car price(s):";
	//	cin >> num1;
	//	wcout << L"input 2nd car price(s):";
	//	cin >> num2;
	//	int sum = buy(num1, num2);
	//	wcout << L"Buy Total cars in " << sum << "0T.krw\n";
	//	wcout << L"\n";
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int num1, num2;
	//	wcout << L"input 1st integer:";
	//	cin >> num1;
	//	wcout << L"input 2nd integer:";
	//	cin >> num2;
	//	st = clock();
	//	wcout << L"max number is " << max(num1, num2) << L".\n";
	//	/*wcout << L"max number is " << max() << L".\n";*/
	//	/*wcout << L"max number is " << max(num1) << L".\n";*/
	//	/*wcout << L"max number is " << max(num2) << L".\n";*/
	//	et = clock();
	//	wcout << L"estimated time(msec):" << float(et - st) << L"\n";
	//	wcout << L"\n";
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int num1, num2;
	//	wcout << L"input 1st integer:";
	//	cin >> num1;
	//	wcout << L"input 2nd integer:";
	//	cin >> num2;
	//	st = clock();
	//	wcout << L"max number is " << max(num1, num2) << L".\n";
	//	et = clock();
	//	//wcout << L"estimated time(msec):" << float(et - st) << L"\n";
	//	double num3, num4;
	//	wcout << L"\n";
	//	wcout << L"input 1st double:";
	//	cin >> num3;
	//	wcout << L"input 2nd double:";
	//	cin >> num4;
	//	st = clock();
	//	wcout << L"max number is " << max(num3, num4) << L".\n";
	//	et = clock();
	//	//wcout << L"estimated time(msec):" << float(et - st) << L"\n";
	//	wcout << L"\n";
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int num1, num2;
	//	wcout << L"input 1st integer:";
	//	cin >> num1;
	//	wcout << L"input 2nd integer:";
	//	cin >> num2;
	//	st = clock();
	//	wcout << L"sum of 2 powered number is " << sqr(num1, num2) << L".\n";
	//	et = clock();
	//	//wcout << L"estimated time(msec):" << float(et - st) << L"\n";
	//	double num3, num4;
	//	wcout << L"\n";
	//	wcout << L"input 1st double:";
	//	cin >> num3;
	//	wcout << L"input 2nd double:";
	//	cin >> num4;
	//	st = clock();
	//	wcout << L"sum of 2 powered number is " << sqr(num3, num4) << L".\n";
	//	et = clock();
	//	//wcout << L"estimated time(msec):" << float(et - st) << L"\n";
	//	wcout << L"\n";
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int a = 5, b = 10, *p;
	//	int &r = a;
	//	wcout << L"value of 'a' is " << a << ".\n";
	//	wcout << L"adress of 'a' is " << &a << ".\n";
	//	wcout << L"value of 'r' is " << r << ".\n";
	//	wcout << L"adress of 'r' is " << &r << ".\n";
	//	wcout << L"\n";
	//	p = &a;
	//	wcout << L"value of 'a' is " << a << ".\n";
	//	wcout << L"adress of 'a' is " << &a << ".\n";
	//	wcout << L"value of 'p' is " << p << ".\n";
	//	wcout << L"value of address 'p' is " << *p << ".\n";
	//	wcout << L"\n";
	//	p = &b;
	//	wcout << L"value of 'b' is " << b << ".\n";
	//	wcout << L"adress of 'b' is " << &b << ".\n";
	//	wcout << L"value of 'p' is " << p << ".\n";
	//	wcout << L"value of address 'p' is " << *p << ".\n";
	//	wcout << L"\n";
	//	//*p = 50;		//��������������(Indirection Operator: *)
	//	//wcout << L"value of 'b' is " << b << ".\n";
	//	//wcout << L"adress of 'b' is " << &b << ".\n";
	//	//wcout << L"value of 'p' is " << p << ".\n";
	//	//wcout << L"value of address 'p' is " << *p << ".\n";
	//	//wcout << L"\n";
	//	swp(a, b);		// Pass by Reference
	//	swp(&a, &b);	// Call by Reference
	//	p = &a;
	//	wcout << L"value of 'a' is " << a << ".\n";
	//	wcout << L"adress of 'a' is " << &a << ".\n";
	//	wcout << L"value of 'p' is " << p << ".\n";
	//	wcout << L"value of address 'p' is " << *p << ".\n";
	//	wcout << L"\n";
	//	p = &b;
	//	wcout << L"value of 'b' is " << b << ".\n";
	//	wcout << L"adress of 'b' is " << &b << ".\n";
	//	wcout << L"value of 'p' is " << p << ".\n";
	//	wcout << L"value of address 'p' is " << *p << ".\n";
	//	wcout << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int a = 5, b = 10;
	//	wcout << L"value of 'a' is " << a << ".\n";
	//	wcout << L"value of 'b' is " << b << ".\n";
	//	wcout << L"\n";
	//	wcout << L"Sum of 'Pass by Reference' is  is " << sum(a, b) << ".\n";
	//	wcout << L"value of 'a + 50' is " << a << ".\n";
	//	wcout << L"value of 'b + 50' is " << b << ".\n";
	//	wcout << L"\n";
	//	wcout << L"Sum of 'Reference Copy' is  is " << sum(&a, &b) << ".\n";
	//	wcout << L"value of 'a + 50' is " << a << ".\n";
	//	wcout << L"value of 'b + 50' is " << b << ".\n";
	//	wcout << L"\n";
	//	wcout << L"��...\n\n";
	//	break;
	//}

	//while (true)
	//{
	//	//int a[] = { 0,1,2,3,4 };
	//	int a[5];
	//	a[0] = 10;
	//	a[1] = 20;
	//	a[2] = 30;
	//	a[3] = 40;
	//	a[4] = 50;
	//	wcout << L"size of 'a' is " << getSize(a) << L"\n";
	//	for (int i = 0; i < (sizeof(a) / sizeof(*a)); i++)
	//	{
	//		wcout << L"value of 'a[" << i << "]' is " << a[i] << ".\n";
	//	}
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int len = 5;
	//	wcout << L"input count(int):";
	//	//cin >> len;
	//	wcout << L"\n";
	//	wcout << L"count is " << len << "\n";
	//	int *a = new int[len];
	//	int *p = a;
	//	wcout << L"size of 'a' is " << sizeof(a) << L", size of '*a' is " << sizeof(*a) << L", '(sizeof(a) / sizeof(*a))' is " << (sizeof(a) / sizeof(*a)) << L"\n";
	//	//for (int i = 0; i < (sizeof(a) / sizeof(*a)); i++)
	//	for (int i = 0; i < len; i++)
	//	{
	//		wcout << L"input value of 'a[" << i << L"]':" << len - i << L"\n";
	//		//cin >> a[i];
	//		//a[i] = len - i;
	//		*a = len - i;
	//		a++;
	//	}
	//	//Bubble Sorting
	//	//for (int i = 0; i < (sizeof(a) / sizeof(*a)); i++)
	//	for (int i = 0; i < len; i++)
	//	{
	//		for (int j = i; j < len; j++)
	//		{
	//			if (a[i] > a[j])
	//			{
	//				//wcout << L"output value of 'a[" << i << L"]':" << a[i] << L" 'a[" << j << L"]':" << a[j] << L"\n";
	//				swap(a[i], a[j]);
	//			}
	//		}
	//	}
	//	//wcout << L"\n";
	//	a = p;
	//	//for (int i = 0; i < (sizeof(a) / sizeof(*a)); i++)
	//	for (int i = 0; i < len; i++)
	//	{
	//		//wcout << L"output value of 'a[" << i << L"]':" << a[i] << L"\n";
	//		wcout << L"output value of 'a[" << i << L"]':" << *a << L"\n";
	//		a++;
	//	}
	//	wcout << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int num = 5;
	//	wcout << L"input count(int):";
	//	//cin >> num;
	//	wcout << L"\n";
	//	wcout << L"count is " << num << "\n";
	//	const int len = num;
	//	int *a;
	//	/*int a[5] = { 1,2,3,4,5 };*/
	//	/*vector<int> a;*/
	//	/*wcout << L"size of 'a' is " << a.size << L"\n";*/
	//	//for (int i = 0; i < (sizeof(a) / sizeof(*a)); i++)
	//	for (int i = 0; i < len; i++)
	//	{
	//		wcout << L"input value of 'a[" << i << L"]':" << len - i << L"\n";
	//		//cin >> a[i];
	//		//a[i] = len - i;
	//		*a = len - i;
	//		a++;
	//	}
	//	//Bubble Sorting
	//	//for (int i = 0; i < (sizeof(a) / sizeof(*a)); i++)
	//	for (int i = 0; i < len; i++)
	//	{
	//		for (int j = i; j < len; j++)
	//		{
	//			if (a[i] > a[j])
	//			{
	//				//wcout << L"output value of 'a[" << i << L"]':" << a[i] << L" 'a[" << j << L"]':" << a[j] << L"\n";
	//				swap(a[i], a[j]);
	//			}
	//		}
	//	}
	//	//wcout << L"\n";
	//	/*a = p;*/
	//	//for (int i = 0; i < (sizeof(a) / sizeof(*a)); i++)
	//	for (int i = 0; i < len; i++)
	//	{
	//		//wcout << L"output value of 'a[" << i << L"]':" << a[i] << L"\n";
	//		wcout << L"output value of 'a[" << i << L"]':" << *a << L"\n";
	//		a++;
	//	}
	//	wcout << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	const int num = 10;
	//	int a[2][num] = {
	//		{80, 60 ,22, 50, 75, 90, 55, 68, 72, 58},
	//		{80, 60 ,22, 50, 75, 90, 55, 68, 72, 58}
	//	};
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	const int len = 10;
	//	int a[len] = { 80, 60 ,22, 50, 75, 90, 55, 68, 72, 58 };
	//	wcout << L"array of 'a's is { 80, 60 ,22, 50, 75, 90, 55, 68, 72 }\n";
	//	wcout << L"value of 'a' is " << *a << L"\t";
	//	wcout << L"address of 'a' is" << &a << L"\n";
	//	wcout << L"\n";
	//	for (int i = 0; i < len; i++)
	//	{
	//		wcout << L"value of 'a[" << i << L"]':" << a[i] << L"\t";
	//		wcout << L"address of 'a[" << i << L"]':" << &a[i] << L"\n";
	//	}
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	const int len = 10;
	//	int a[len] = { 80, 60 ,22, 50, 75, 90, 55, 68, 72, 58 };
	//	wcout << L"array of 'a's is { 80, 60 ,22, 50, 75, 90, 55, 68, 72, 58 }\n";
	//	wcout << L"size of 'a' is " << sizeof(a) << L", size of '*a' is " << sizeof(*a) << L", '(sizeof(a) / sizeof(*a))' is " << (sizeof(a) / sizeof(*a)) << L"\n";
	//	//wcout << L"value of 'a' is " << *a << L"\t";
	//	//wcout << L"address of 'a' is" << &a << L"\n";
	//	wcout << L"average array values of 'a' is " << avg(a) << L"\n";
	//	wcout << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";


	//while (true)
	//{
	//	//char str[5] = { 'H', 'e', 'l', 'l', '\0' };
	//	//char str[] = { 'H', 'e', 'l', 'l', '\0' };
	//	//char str[] = "Hell";
	//	//str[] = "Hi";
	//	char* str = "Hell";
	//	//str = "Hi";
	//	wcout << str << L"\n";
	//	for (int i = 0; str[i] != '\0'; i++)
	//	{
	//		wcout << str[i] << L"*";
	//	}
	//	wcout << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	char str0[20];
	//	char str1[10];
	//	char str2[10];
	//	strcpy_s(str1, "Hell");
	//	strcpy_s(str2, "Goodbye");
	//	strcpy_s(str0, str1);
	//	strcat_s(str0, str2);
	//	wcout << L"str1 is '" << str1 << L"'.\n";
	//	wcout << L"str2 is '" << str2 << L"'.\n";
	//	wcout << L"str1 + str2 is '" << str0 << L"'.\n";
	//	wcout << L"str1 + str2 length is '" << len(str0) << L"'.\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	char str[100];
	//	char ch;
	//	wcout << L"input string.:\n";
	//	cin >> str;
	//	wcout << L"input search character.:\n";
	//	cin >> ch;
	//	wcout << L"count of searched character is " << count(str, ch) << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";


	//while (true)
	//{
	//	int a = 1;
	//	a++;
	//	wcout << L"local val is " << a << L"\n";
	//	::a++;
	//	wcout << L"global val is " << ::a << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	for (int i = 0; i < 5; i++)
	//	{
	//		//wcout << func() << L"\n";
	//		int *p = func();
	//		wcout << p << L"\n";
	//		wcout << *p << L"\n";
	//		wcout << L"\n";
	//	}
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int *a;
	//	a = new int;
	//	*a = 50;
	//	wcout << a << L"\n";
	//	//break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	int len;
	//	int *p;
	//	wcout << L"input count of students to record:\n";
	//	cin >> len;
	//	p = new int[len];
	//	wcout << L"input " << len << L" students to record.\n";
	//	for (int i = 0; i < len; i++)
	//	{
	//		wcout << L"no." << i + 1 << L" student's record:";
	//		cin >> p[i];
	//	}
	//	wcout << L"\n";
	//	for (int i = 0; i < len; i++)
	//	{
	//		wcout << L"no." << i + 1 << L" student's record is " << p[i] << L".\n";
	//	}
	//	delete p;
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	Week w;
	//	w = MON;
	//	switch (w)
	//	{
	//	case SUN: wcout << L"this is " << w << L" day.\n";
	//		break;
	//	case MON: wcout << L"this is " << w << L" day.\n";
	//		break;
	//	case TUE: wcout << L"this is " << w << L" day.\n";
	//		break;
	//	case WED: wcout << L"this is " << w << L" day.\n";
	//		break;
	//	case THU: wcout << L"this is " << w << L" day.\n";
	//		break;
	//	case FRI: wcout << L"this is " << w << L" day.\n";
	//		break;
	//	case SAT: wcout << L"this is " << w << L" day.\n";
	//		break;
	//	default:
	//		break;
	//	}
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	Car c1 = { 1, 1234.1 }, c2 = { 2, 4321.4 };
	//	//wcout << L"input car no:";
	//	//cin >> c1.num;
	//	//wcout << L"input car no." << c1.num << "'s gas amount:";
	//	//cin >> c1.gas;
	//	//wcout << L"car no." << c1.num << "'s gas amount is " << c1.gas << L".\n";
	//	//wcout << L"car no." << c2.num << "'s gas amount is " << c2.gas << L".\n";
	//	show(&c1);
	//	show(&c2);
	//	wcout << L"car no." << c1.num << "'s gas amount is " << c1.gas << L".\n";
	//	wcout << L"car no." << c2.num << "'s gas amount is " << c2.gas << L".\n";
	//	wcout << L"\n";
	//	show(c1);
	//	show(c2);
	//	wcout << L"car no." << c1.num << "'s gas amount is " << c1.gas << L".\n";
	//	wcout << L"car no." << c2.num << "'s gas amount is " << c2.gas << L".\n";
	//	wcout << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	Year y;
	//	wcout << L"input AD year:";
	//	cin >> y.ad;
	//	wcout << L"input Dangi year:";
	//	cin >> y.de;
	//	wcout << L"AD year is " << y.ad << L".\n";
	//	wcout << L"Dangi year is " << y.de << L".\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	Car *c1 = new Car(1, 1234.1);
	//	//c1->num = 1;
	//	//c1->gas = 1234.1;
	//	//c1->setNumGas(1, 1234.1);
	//	//c1->show();
	//	Car *c2 = new Car(2, 4321.4);
	//	//c2->num = 2;
	//	//c2->gas = 4321.4;
	//	//c2->setNumGas(2, 4321.4);
	//	//c2->show();
	//	//buyCar(c1);
	//	//buyCar(*c1);
	//	Car *c3 = new Car(3, 5678.5);
	//	//c3->show();
	//	Car *c4 = new Car(4, 8765.8);
	//	//c4->show();
	//	RaceCar *rc = new RaceCar(5, 5678.5, 350, 9);
	//	//rc->show();
	//	wcout << L"\n";
	//	Car *cs[5] = { c1, c2, c3, c4, rc };
	//	wcout << L"size of 'cs' is " << sizeof(cs) << L", size of '*cs' is " << sizeof(*cs) << L", '(sizeof(cs) / sizeof(*cs))' is " << (sizeof(cs) / sizeof(*cs)) << L"\n";
	//	Car::showSum();
	//	wcout << L"\n";
	//	for (int i = 0; i < sizeof(cs) / sizeof(*cs); i++)
	//	{
	//		cs[i]->show();
	//	}
	//	wcout << L"\n";
	//	delete c1, c2, c3, c4, rc;
	//	/*cin >> res;*/
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	Car *c1 = new Car(1, 1234.1, 60);
	//	c1->show();
	//	Plane *p1 = new Plane(747, 300);
	//	p1->show();
	//	RaceCar *r1 = new RaceCar(5, 4321.4, 350, 9);
	//	r1->show();
	//	Vehicle *v[3] = { c1, p1 , r1 };
	//	wcout << L"\n";
	//	wcout << L"size of 'v' is " << sizeof(v) << L", size of '*v' is " << sizeof(*v) << L", '(sizeof(v) / sizeof(*v))' is " << (sizeof(v) / sizeof(*v)) << L"\n";
	//	Car::showSum();
	//	wcout << L"\n";
	//	for (int i = 0; i < sizeof(v) / sizeof(*v); i++)
	//	{
	//		v[i]->show();
	//		if ((typeid(*v[i])) == typeid(Car))
	//		{
	//			wcout << L"This is '" << typeid(Car).name() << L"'!!!";
	//		}
	//		else
	//		{
	//			wcout << L"This is NOT '" << typeid(Car).name() << L"'!!!";
	//		}
	//		wcout << i + 1 << L"'s object is '" << typeid(*v[i]).name() << L"'. ";
	//		wcout << L"\n";
	//	}
	//	wcout << L"\n";
	//	delete c1, p1, r1;
	//	/*cin >> res;*/
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	Point p = Point(1, 3) + Point(5, 2);
	//	Point p1(1, 3), p2(5, 2), p3, p4;
	//	wcout << L"p1"; p1.show();
	//	wcout << L"p2"; p2.show();
	//	wcout << L"p = p1 + p2\n";
	//	p = p1 + p2;
	//	p.show();
	//	wcout << L"p = 3 + p2\n";
	//	p = 3 + p2;
	//	p.show();
	//	wcout << L"p = p1 + 3\n";
	//	p = p1 + 3;
	//	p.show();
	//	wcout << L"\n";
	//	wcout << L"p1"; p1.show();
	//	wcout << L"p = p1++\n";
	//	p = p1++;
	//	wcout << L"p1"; p1.show();
	//	wcout << L"p"; p.show();
	//	wcout << L"\n";
	//	wcout << L"p2"; p2.show();
	//	wcout << L"p = ++p2\n";
	//	p = ++p2;
	//	wcout << L"p2"; p2.show();
	//	wcout << L"p"; p.show();
	//	wcout << L"\n";
	//	wcout << L"p"; p.show();
	//	wcout << L"p = ++p++\n";
	//	p = ++p++;
	//	wcout << L"p"; p.show();
	//	wcout << L"\n";
	//	wcout << L"p1"; p1.show();
	//	wcout << L"p = ++p1++\n";
	//	p = ++p1++;
	//	wcout << L"p1"; p1.show();
	//	wcout << L"p"; p.show();
	//	wcout << L"\n";
	//	wcout << L"p1"; p1.show();
	//	wcout << L"p = p1++++\n";
	//	p = p1++++;
	//	wcout << L"p1"; p1.show();
	//	wcout << L"p"; p.show();
	//	wcout << L"\n";
	//	wcout << L"p1"; p1.show();
	//	wcout << L"p = ++++p1\n";
	//	p = ++++p1;
	//	wcout << L"p1"; p1.show();
	//	wcout << L"p"; p.show();
	//	wcout << L"\n";
	//	wcout << L"p2"; p2.show();
	//	p3 = p4 = p2;
	//	wcout << L"Point p3 = p2; Point p4 = p2;\n";
	//	wcout << L"(p3++++ == p4++) is " << ((p3++++ == p4++) ? "true" : "false") << L"\n";
	//	wcout << L"p3"; p3.show();
	//	wcout << L"p4"; p4.show();
	//	wcout << L"\n";
	//	wcout << L"p2"; p2.show();
	//	p3 = p4 = p2;
	//	wcout << L"Point p3 = p2; Point p4 = p2;\n";
	//	wcout << L"(++++p3 == ++p4) is " << ((++++p3 == ++p4) ? "true" : "false") << L"\n";
	//	wcout << L"p3"; p3.show();
	//	wcout << L"p4"; p4.show();
	//	wcout << L"\n";
	//	wcout << L"p2"; p2.show();
	//	p3 = p4 = p2;
	//	wcout << L"Point p3 = p2; Point p4 = p2;\n";
	//	wcout << L"((p3++)++ == p4++) is " << (((p3++)++ == p4++) ? "true" : "false") << L"\n";
	//	wcout << L"p3"; p3.show();
	//	wcout << L"p4"; p4.show();
	//	wcout << L"\n";
	//	wcout << L"p2"; p2.show();
	//	p3 = p4 = p2;
	//	wcout << L"Point p3 = p2; Point p4 = p2;\n";
	//	wcout << L"(++(++p3) == ++p4) is " << ((++(++p3) == ++p4) ? "true" : "false") << L"\n";
	//	wcout << L"p3"; p3.show();
	//	wcout << L"p4"; p4.show();
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	Number n1, n2;
	//	n1 = n2 = Number(100);
	//	int i = ++n1++;
	//	double d = --n2--;
	//	//wcout << L"n1:" << n1.toString() << L"\n";
	//	//wcout << L"n2:" << n2.toString() << L"\n";
	//	wcout << L"i:" << i << L"\n";
	//	wcout << L"d:" << d << L"\n";
	//	wcout << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	RaceCar Rcar(2, 4321.4, 400, 9, "RC1");
	//	Rcar.show();
	//	wcout << L"\n";
	//	Car car(1, 1234.1, 60, "C1");
	//	car.show();
	//	wcout << L"\n";
	//	break;
	//}
	//while (true)
	//{
	//	wcout << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	//while (true)
	//{
	//	wcout << L">>Car c1(1, 1234.1, 60, \"C1\")\n";
	//	Car c1(1, 1234.1, 60, "C1");
	//	wcout << L">>c1.show();\n";
	//	c1.show();
	//	wcout << L">>Car c2 = c1\n";
	//	Car c2 = c1;
	//	wcout << L">>c2.show();\n";
	//	c2.show();
	//	wcout << L">>Car c3;\n";
	//	Car c3/* = c2*/;
	//	wcout << L">>c3.show();\n";
	//	c3.show();
	//	wcout << L">>c3 = c1\n";
	//	c3 = c1;
	//	wcout << L">>c3.show();\n";
	//	c3.show();
	//	wcout << L"\n";
	//	break;
	//}
	//wcout << L"��...\n\n";

	return 0;
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    class Calcurator : Form
    {
        Label lblHistory;
        TextBox txtInput;
        List<string> nums = new List<string> { "7", "8", "9", "4", "5", "6", "1", "2", "3", "0", "." };
        List<string> oprs = new List<string> { "+", "-", "*", "/", };
        List<string> func = new List<string> { "CE", "C", "=", };
        Button btn = new Button();

        public Calcurator()
        {
            int idx = 0;
            int x = 0;
            int y = 0;
            int g = 4;
            int m = 4;
            int w = 50;
            //int h = 0;
            lblHistory = new Label()
            {
                Top = 0,
                Width = this.Width - g * m,
                //Enabled = false,
                TextAlign = ContentAlignment.MiddleRight,
            };
            this.Controls.Add(lblHistory);
            txtInput = new TextBox()
            {
                Top = lblHistory.Height + g,
                Width = this.Width - g * m,
                Enabled = false,
                TextAlign = HorizontalAlignment.Right,
            };
            this.Controls.Add(txtInput);
            y = txtInput.Height + g;
            foreach (string item in nums)
            {
                this.btn = new Button() { Text = item, Location = new Point(x, y), Width = w/* * 2 / 3*/, };
                if (idx % 3 == 0)
                {
                    y += this.btn.Height + g;
                    x = 0;
                }
                else
                {
                    x += this.btn.Width + g;
                }
                this.btn.Location = new Point(x, y);
                this.Controls.Add(this.btn);
                if (item == "0")
                {
                    x += this.btn.Width + g;
                    this.btn.Width = this.btn.Width * 2 + g;
                }
                idx++;
                this.btn.Click += Num_Click;
                ResizeFormWidth(this.btn);
                this.AcceptButton = this.btn;
                this.btn.TabStop = false;
            }
            x = this.btn.Left + this.btn.Width + g;
            y = txtInput.Top + txtInput.Height + g;
            foreach (var item in oprs)
            {
                this.btn = new Button() { Text = item, Location = new Point(x, y), Width = w/* * 2 / 3*/, };
                y += this.btn.Height + g;
                this.Controls.Add(this.btn);
                idx++;
                this.btn.Click += Opr_Click;
                ResizeFormWidth(this.btn);
                this.AcceptButton = this.btn;
                this.btn.TabStop = false;
            }
            x = this.btn.Left + this.btn.Width + g;
            y = txtInput.Top + txtInput.Height + g;
            foreach (var item in func)
            {
                this.btn = new Button() { Text = item, Location = new Point(x, y), Width = w/* * 2 / 3*/, };
                if (item == "=")
                {
                    this.btn.Height = this.btn.Height * 2 + g;
                }
                else
                {
                    this.btn.Height = this.btn.Height;
                }
                this.btn.Click += Fun_Click;
                y += this.btn.Height + g;
                this.Controls.Add(this.btn);
                idx++;
                ResizeFormWidth(this.btn);
                this.AcceptButton = this.btn;
                this.btn.TabStop = false;
            }
            foreach (Control item in Controls)
            {
                if (item is Button)
                {
                    item.TabStop = false;
                }
                item.KeyPress += Calcurator_KeyPress;
                item.KeyDown += Calcuator_KeyDown;
            }
            this.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.Calcuator_PreviewKeyDown);
            this.KeyPress += Calcurator_KeyPress;
            this.KeyDown += Calcuator_KeyDown;
            ComputeCalcurator();
        }

        private void Calcuator_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            Debug.WriteLine("Calcuator_PreviewKeyDown:" + sender + "\t" + e);
        }

        private void Calcuator_KeyDown(object sender, KeyEventArgs e)
        {
            Debug.WriteLine("Calcuator_KeyDown:" + sender + "\t" + e);
            switch (e.KeyCode)
            {
                case Keys.Escape:
                    ClearCalcurator();
                    break;
                case Keys.Back:
                case Keys.Delete:
                    DelCalcurator();
                    break;
                case Keys.Enter:
                    break;
                case Keys.Left:
                    break;
                case Keys.Up:
                    break;
                case Keys.Right:
                    break;
                case Keys.Down:
                    break;
                case Keys.D0:
                    break;
                case Keys.D1:
                    break;
                case Keys.D2:
                    break;
                case Keys.D3:
                    break;
                case Keys.D4:
                    break;
                case Keys.D5:
                    break;
                case Keys.D6:
                    break;
                case Keys.D7:
                    break;
                case Keys.D8:
                    break;
                case Keys.D9:
                    break;
                case Keys.NumPad0:
                    break;
                case Keys.NumPad1:
                    break;
                case Keys.NumPad2:
                    break;
                case Keys.NumPad3:
                    break;
                case Keys.NumPad4:
                    break;
                case Keys.NumPad5:
                    break;
                case Keys.NumPad6:
                    break;
                case Keys.NumPad7:
                    break;
                case Keys.NumPad8:
                    break;
                case Keys.NumPad9:
                    break;
                case Keys.Multiply:
                    break;
                case Keys.Add:
                    break;
                case Keys.Separator:
                    break;
                case Keys.Subtract:
                    break;
                case Keys.Decimal:
                    break;
                case Keys.Divide:
                    break;
                default:
                    break;
            }
        }

        private void Calcurator_KeyPress(object sender, KeyPressEventArgs e)
        {
            Debug.WriteLine("Calcurator_KeyPress:" + sender + "\t" + e);
            Calcurator_KeyPress(e.KeyChar.ToString());
        }

        private void Calcurator_KeyPress(string key)
        {
            foreach (Control item in Controls)
            {
                if (item is Button && item.Text == key)
                {
                    if (oprs.Contains(key))
                    {
                        //Opr_Click(item, EventArgs.Empty);
                        Opr_Click(key);
                    }
                    else if (nums.Contains(key))
                    {
                        //Num_Click(item, EventArgs.Empty);
                        Num_Click(key);
                    }
                    else if (func.Contains(key))
                    {
                        //Fun_Click(item, EventArgs.Empty);
                        Fun_Click(key);
                    }
                }
            }
            //this.lblHistory.Focus();
        }

        private void Fun_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("Fun_Click:" + "\t" + ((Control)sender).Text + "\t" + sender + "\t" + e);
            Fun_Click(((Control)sender).Text);
        }

        private void Fun_Click(string key)
        {
            switch (key)
            {
                case "CE":
                    ClearCalcurator();
                    break;
                case "C":
                    DelCalcurator();
                    break;
                case "=":
                    ComputeCalcurator();
                    break;
                default:
                    break;
            }

            this.lblHistory.Focus();
        }

        private void ClearCalcurator()
        {
            lblHistory.Text = txtInput.Text = "";
        }

        private void DelCalcurator()
        {
            txtInput.Text = txtInput.Text.Substring(0, txtInput.Text.Length - 1);
        }

        private void ComputeCalcurator()
        {
            try
            {
                //DataTable dt = new DataTable();
                //var v = dt.Compute("3 * (2+4)", "");
                //txtInput.Text = v.ToString();
                txtInput.Text = (new DataTable()).Compute(txtInput.Text, "").ToString();

            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }

        private void Opr_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("Opr_Click:" + "\t" + ((Control)sender).Text + "\t" + sender + "\t" + e);
            Opr_Click(((Control)sender).Text);
        }

        private void Opr_Click(string key)
        {
            foreach (var item in oprs)
            {
                if (txtInput.Text.Contains(item))
                {
                    return;
                }
            }
            txtInput.Text += " " + key + " ";

            lblHistory.Text = txtInput.Text;

            this.lblHistory.Focus();
        }

        private void Num_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("Num_Click:" + "\t" + ((Control)sender).Text + "\t" + sender + "\t" + e);
            Num_Click(((Control)sender).Text);
        }

        private void Num_Click(string key)
        {
            lblHistory.Text = txtInput.Text += key;

            this.lblHistory.Focus();
        }

        private void ResizeParent(Control parent)
        {
            int g = 12 / 2;
            int w = parent.Controls[0].Width * 2 + g * 4;
            int h = 0;
            int t = g * 2;
            foreach (Control item in parent.Controls)
            {
                int ww = (item.Width * 2 + +g * 4);
                w = ww > w ? ww : w;
                h += item.Height + g;
                item.Left = g;
                item.Top = t;
                t += item.Height + g;
            }
            h += g * 2;
            parent.Width = w;
            parent.Height = h;
        }

        private void ResizeFormWidth(Control control)
        {
            int g = 12;
            int w = 0;
            int h = this.Height;
            w += control.Left + control.Width + g;
            this.Width = w;
            this.Width = h;
        }

        private void ResizeFormHeight(Control control)
        {
            int g = 12;
            int w = this.Width;
            int h = 0;
            h += control.Top + control.Height + g;
            h += g * 5;
            this.Width = w;
            this.Height = h;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.startButton = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label_timer = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDown_inch = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_cm = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label_cm = new System.Windows.Forms.Label();
            this.textBox_inch = new System.Windows.Forms.TextBox();
            this.textBox_cm = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.numericUpDown_lb = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_kg = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_lb = new System.Windows.Forms.TextBox();
            this.textBox_kg = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goToGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button7 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_inch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_cm)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_lb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_kg)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(2, 27);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(75, 23);
            this.startButton.TabIndex = 0;
            this.startButton.Text = "시작";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label_timer
            // 
            this.label_timer.AutoSize = true;
            this.label_timer.Location = new System.Drawing.Point(83, 38);
            this.label_timer.Name = "label_timer";
            this.label_timer.Size = new System.Drawing.Size(38, 12);
            this.label_timer.TabIndex = 1;
            this.label_timer.Text = "label1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown_inch);
            this.groupBox1.Controls.Add(this.numericUpDown_cm);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label_cm);
            this.groupBox1.Controls.Add(this.textBox_inch);
            this.groupBox1.Controls.Add(this.textBox_cm);
            this.groupBox1.Location = new System.Drawing.Point(2, 79);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(330, 86);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            // 
            // numericUpDown_inch
            // 
            this.numericUpDown_inch.DecimalPlaces = 5;
            this.numericUpDown_inch.Location = new System.Drawing.Point(202, 20);
            this.numericUpDown_inch.Name = "numericUpDown_inch";
            this.numericUpDown_inch.Size = new System.Drawing.Size(100, 21);
            this.numericUpDown_inch.TabIndex = 16;
            this.numericUpDown_inch.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_inch.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_inch.Click += new System.EventHandler(this.textBox_Click);
            // 
            // numericUpDown_cm
            // 
            this.numericUpDown_cm.DecimalPlaces = 5;
            this.numericUpDown_cm.Location = new System.Drawing.Point(22, 20);
            this.numericUpDown_cm.Name = "numericUpDown_cm";
            this.numericUpDown_cm.Size = new System.Drawing.Size(100, 21);
            this.numericUpDown_cm.TabIndex = 15;
            this.numericUpDown_cm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_cm.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_cm.Click += new System.EventHandler(this.textBox_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(308, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(10, 12);
            this.label1.TabIndex = 11;
            this.label1.Text = "\"";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(155, 44);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(38, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "↔";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label_cm
            // 
            this.label_cm.AutoSize = true;
            this.label_cm.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_cm.Location = new System.Drawing.Point(129, 55);
            this.label_cm.Name = "label_cm";
            this.label_cm.Size = new System.Drawing.Size(25, 12);
            this.label_cm.TabIndex = 10;
            this.label_cm.Text = "cm";
            // 
            // textBox_inch
            // 
            this.textBox_inch.Location = new System.Drawing.Point(202, 46);
            this.textBox_inch.MaxLength = 10;
            this.textBox_inch.Name = "textBox_inch";
            this.textBox_inch.Size = new System.Drawing.Size(100, 21);
            this.textBox_inch.TabIndex = 9;
            this.textBox_inch.Text = "1";
            this.textBox_inch.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox_inch.Click += new System.EventHandler(this.textBox_Click);
            this.textBox_inch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox_cm
            // 
            this.textBox_cm.Location = new System.Drawing.Point(22, 47);
            this.textBox_cm.MaxLength = 10;
            this.textBox_cm.Name = "textBox_cm";
            this.textBox_cm.Size = new System.Drawing.Size(100, 21);
            this.textBox_cm.TabIndex = 8;
            this.textBox_cm.Text = "1";
            this.textBox_cm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox_cm.Click += new System.EventHandler(this.textBox_Click);
            this.textBox_cm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(157, 49);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(38, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "↔";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(246, 27);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(38, 23);
            this.button3.TabIndex = 12;
            this.button3.Text = "▶";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(246, 50);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(38, 23);
            this.button4.TabIndex = 12;
            this.button4.Text = "◀";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.numericUpDown_lb);
            this.groupBox2.Controls.Add(this.numericUpDown_kg);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.textBox_lb);
            this.groupBox2.Controls.Add(this.textBox_kg);
            this.groupBox2.Location = new System.Drawing.Point(3, 171);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(329, 100);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            // 
            // numericUpDown_lb
            // 
            this.numericUpDown_lb.DecimalPlaces = 5;
            this.numericUpDown_lb.Location = new System.Drawing.Point(201, 23);
            this.numericUpDown_lb.Name = "numericUpDown_lb";
            this.numericUpDown_lb.Size = new System.Drawing.Size(100, 21);
            this.numericUpDown_lb.TabIndex = 17;
            this.numericUpDown_lb.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_lb.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_lb.Click += new System.EventHandler(this.textBox_Click);
            // 
            // numericUpDown_kg
            // 
            this.numericUpDown_kg.DecimalPlaces = 5;
            this.numericUpDown_kg.Location = new System.Drawing.Point(24, 21);
            this.numericUpDown_kg.Name = "numericUpDown_kg";
            this.numericUpDown_kg.Size = new System.Drawing.Size(100, 21);
            this.numericUpDown_kg.TabIndex = 16;
            this.numericUpDown_kg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_kg.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_kg.Click += new System.EventHandler(this.textBox_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(307, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 11;
            this.label2.Text = "lb";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(131, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "kg";
            // 
            // textBox_lb
            // 
            this.textBox_lb.Location = new System.Drawing.Point(201, 50);
            this.textBox_lb.MaxLength = 10;
            this.textBox_lb.Name = "textBox_lb";
            this.textBox_lb.Size = new System.Drawing.Size(100, 21);
            this.textBox_lb.TabIndex = 9;
            this.textBox_lb.Text = "1";
            this.textBox_lb.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox_lb.Click += new System.EventHandler(this.textBox_Click);
            this.textBox_lb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox_kg
            // 
            this.textBox_kg.Location = new System.Drawing.Point(24, 49);
            this.textBox_kg.MaxLength = 10;
            this.textBox_kg.Name = "textBox_kg";
            this.textBox_kg.Size = new System.Drawing.Size(100, 21);
            this.textBox_kg.TabIndex = 8;
            this.textBox_kg.Text = "1";
            this.textBox_kg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox_kg.Click += new System.EventHandler(this.textBox_Click);
            this.textBox_kg.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(290, 50);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(38, 23);
            this.button6.TabIndex = 14;
            this.button6.Text = "◀";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Visible = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(290, 27);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(38, 23);
            this.button5.TabIndex = 13;
            this.button5.Text = "▶";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Visible = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileFToolStripMenuItem,
            this.editEToolStripMenuItem,
            this.viewVToolStripMenuItem,
            this.projectPToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(343, 24);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileFToolStripMenuItem
            // 
            this.fileFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newNToolStripMenuItem,
            this.openOToolStripMenuItem});
            this.fileFToolStripMenuItem.Name = "fileFToolStripMenuItem";
            this.fileFToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.fileFToolStripMenuItem.Text = "File(&F)";
            // 
            // newNToolStripMenuItem
            // 
            this.newNToolStripMenuItem.Name = "newNToolStripMenuItem";
            this.newNToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.newNToolStripMenuItem.Text = "New(&N)";
            // 
            // openOToolStripMenuItem
            // 
            this.openOToolStripMenuItem.Name = "openOToolStripMenuItem";
            this.openOToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.openOToolStripMenuItem.Text = "Open(&O)";
            // 
            // editEToolStripMenuItem
            // 
            this.editEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.goToGToolStripMenuItem});
            this.editEToolStripMenuItem.Name = "editEToolStripMenuItem";
            this.editEToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.editEToolStripMenuItem.Text = "Edit(&E)";
            // 
            // goToGToolStripMenuItem
            // 
            this.goToGToolStripMenuItem.Name = "goToGToolStripMenuItem";
            this.goToGToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.goToGToolStripMenuItem.Text = "Go To(&G)";
            // 
            // viewVToolStripMenuItem
            // 
            this.viewVToolStripMenuItem.Name = "viewVToolStripMenuItem";
            this.viewVToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.viewVToolStripMenuItem.Text = "View(&V)";
            // 
            // projectPToolStripMenuItem
            // 
            this.projectPToolStripMenuItem.Name = "projectPToolStripMenuItem";
            this.projectPToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.projectPToolStripMenuItem.Text = "Project(&P)";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 593);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(343, 22);
            this.statusStrip1.TabIndex = 16;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.productBindingSource;
            this.comboBox1.DisplayMember = "Name";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(3, 278);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(329, 20);
            this.comboBox1.TabIndex = 17;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataSource = typeof(WindowsFormsApp1.Product);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(4, 563);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(71, 23);
            this.button7.TabIndex = 18;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(85, 564);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(247, 21);
            this.textBox1.TabIndex = 19;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.productBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(4, 408);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(328, 150);
            this.dataGridView1.TabIndex = 20;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            // 
            // listBox1
            // 
            this.listBox1.DataSource = this.productBindingSource;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(4, 305);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(328, 88);
            this.listBox1.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 615);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label_timer);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.Form1_PreviewKeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_inch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_cm)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_lb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_kg)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void Form1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label_timer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_cm;
        private System.Windows.Forms.TextBox textBox_inch;
        private System.Windows.Forms.TextBox textBox_cm;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_lb;
        private System.Windows.Forms.TextBox textBox_kg;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.NumericUpDown numericUpDown_cm;
        private System.Windows.Forms.NumericUpDown numericUpDown_inch;
        private System.Windows.Forms.NumericUpDown numericUpDown_lb;
        private System.Windows.Forms.NumericUpDown numericUpDown_kg;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projectPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goToGToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.BindingSource productBindingSource;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ListBox listBox1;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        List<Button> lb = new List<Button>() { new Button(), new Button(), new Button(), new Button(), new Button(), };

        object lastFocus = null;

        class CustomForm : Form
        {
            public CustomForm()
            {

            }
        }

        private void showCalculator()
        {
            Calcurator cf = new Calcurator();
            cf.Show();
        }

        public Form1()
        {
            InitializeComponent();
            this.IsMdiContainer = true;

            this.startButton.Text = "코드로변경";
            //this.startButton.Width += 100;

            //Button makeButton = new Button();
            //makeButton.Text = "make";
            //makeButton.Top = this.startButton.Bottom + 10;
            //makeButton.Left = this.startButton.Left;
            //makeButton.Width = this.startButton.Width;
            //this.Controls.Add(makeButton);

            int t = this.groupBox2.Top + this.groupBox2.Height;
            int g = 12;

            Label txt = new Label()
            {
                Text = "Label",
                Location = new Point(g, t + g),
                TextAlign = ContentAlignment.MiddleLeft
            };
            t = txt.Top + txt.Height;
            LinkLabel lnk = new LinkLabel()
            {
                Text = "Naver",
                Location = new Point(g, t + g),
                TextAlign = ContentAlignment.MiddleLeft
            };
            lnk.Click += LabelClick;

            this.Controls.Add(txt);
            this.Controls.Add(lnk);


            t = lnk.Top + lnk.Height;
            CheckBox cbx1 = new CheckBox()
            {
                Text = " Potato",
                Location = new Point(g, t + g)
            };
            t = cbx1.Top + cbx1.Height;
            CheckBox cbx2 = new CheckBox()
            {
                Text = " Tomato",
                Location = new Point(g, t + g)
            };
            t = cbx2.Top + cbx2.Height;
            CheckBox cbx3 = new CheckBox()
            {
                Text = " Banana",
                Location = new Point(g, t + g)
            };
            this.Controls.Add(cbx1);
            this.Controls.Add(cbx2);
            this.Controls.Add(cbx3);

            t = cbx3.Top + cbx3.Height;
            RadioButton rdb1 = new RadioButton()
            {
                Text = " Potato"
                //Text = " Potato",
                //Location = new Point(g, t + g)
            };
            t = rdb1.Top + rdb1.Height;
            RadioButton rdb2 = new RadioButton()
            {
                Text = " Tomato"
                //Text = " Tomato",
                //Location = new Point(g, t + g)
            };
            t = rdb2.Top + rdb2.Height;
            RadioButton rdb3 = new RadioButton()
            {
                Text = " Banana"
                //Text = " Banana",
                //Location = new Point(g, t + g)
            };
            this.Controls.Add(rdb1);
            this.Controls.Add(rdb2);
            this.Controls.Add(rdb3);

            t = cbx3.Top + cbx3.Height;
            GroupBox gbx = new GroupBox()
            {
                Text = "",
                Location = new Point(g, t + g)
            };
            gbx.Controls.Add(rdb1);
            gbx.Controls.Add(rdb2);
            gbx.Controls.Add(rdb3);
            this.Controls.Add(gbx);
            ResizeParent(gbx);

            t = gbx.Top + gbx.Height;
            Button btn1 = new Button()
            {
                Text = "Click!",
                Location = new Point(g, t + g)
            };
            this.Controls.Add(btn1);

            btn1.Click += ButtonClick;

            ResizeFormWidth(groupBox1);
            ResizeFormHeight(btn1);

            productBindingSource.Add(new Product() { Name = "Potato", Price = 1000 });
            productBindingSource.Add(new Product() { Name = "Tomato", Price = 2000 });
            productBindingSource.Add(new Product() { Name = "Banana", Price = 3000 });

            //Thread th = new Thread(showCalculator);
            //th.Start();
            showCalculator();

            this.WindowState = FormWindowState.Minimized;
        }

        private void ResizeParent(Control parent)
        {
            int g = 12 / 2;
            int w = parent.Controls[0].Width * 2 + g * 4;
            int h = 0;
            int t = g * 2;
            foreach (Control item in parent.Controls)
            {
                int ww = (item.Width * 2 + +g * 4);
                w = ww > w ? ww : w;
                h += item.Height + g;
                item.Left = g;
                item.Top = t;
                t += item.Height + g;
            }
            h += g * 2;
            parent.Width = w;
            parent.Height = h;
        }

        private void ResizeFormWidth(Control control)
        {
            int g = 12;
            int w = 0;
            int h = this.Height;
            w += /*control.Left + */control.Width + g;
            this.Width = w;
            this.Width = h;
        }

        private void ResizeFormHeight(Control control)
        {
            int g = 12;
            int w = this.Width;
            int h = 0;
            h += control.Top + control.Height + g;
            h += g * 5;
            this.Width = w;
            this.Height = h;
        }

        private void ResizeForm()
        {
            int g = 12;
            int w = this.startButton.Width * 2 + g * 4;
            int h = 0;
            foreach (var item in this.lb)
            {
                int ww = (this.startButton.Width + item.Width + g * 4);
                w = ww > w ? ww : w;
                h += item.Height + g;
            }
            h += g * 4;
            this.Width = w;
            this.Height = h;
        }

        private void ButtonClick(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            List<string> ls = new List<string>();
            foreach (Control outter in Controls)
            {
                try
                {
                    if (outter is GroupBox)
                    {
                        foreach (Control inner in outter.Controls)
                        {
                            RadioButton rdb = (RadioButton)outter;
                            if (rdb.Checked)
                            {
                                ls.Add(rdb.Text);
                            }
                        }
                    }
                    CheckBox cbx = (CheckBox)outter;
                    if (cbx.Checked)
                    {
                        ls.Add(cbx.Text);
                    }
                }
                catch (Exception)
                {
                    continue;
                }
            }
            MessageBox.Show(string.Join(",", ls));
        }

        private void LabelClick(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            Process.Start("http://nave.com");
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            TraceWriteLine(sender, e);
            textBox_cm.Text = "1";
            textBox_inch.Text = "1";
            textBox_kg.Text = "1";
            textBox_lb.Text = "1";

            numericUpDown_cm.Value = 1;
            numericUpDown_inch.Value = 1;
            numericUpDown_kg.Value = 1;
            numericUpDown_lb.Value = 1;

            //MessageBox.Show("메시지박스", "메시지", MessageBoxButtons.OK);

            //Form1 f1 = new Form1();
            //f1.MdiParent = this;
            //f1.Show();

            //CustomForm cf = new CustomForm();
            ////cf.MdiParent = this;
            ////cf.Show();
            //cf.ShowDialog();

            showCalculator();
        }

        private void textBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void textBox_Click(object sender, EventArgs e)
        {
            //TraceWriteLine(sender, e);
            this.lastFocus = sender;
            TraceWriteLine(this.lastFocus, e);
        }

        private void MakeButtons()
        {
            int idx = 0;
            int g = 12;
            int x = startButton.Right + g;
            int y = startButton.Top;
            int p = idx * (startButton.Height + g);
            foreach (var item in this.lb)
            {
                item.Text = "Button" + idx;
                p = (idx * (startButton.Height + g));
                item.Location = new Point(x, y + p);
                item.Width = startButton.Width;
                this.Controls.Add(item);
                item.Click += Button_Click;
                idx++;
            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            TraceWriteLine(sender, e);
            ((Button)sender).Width += 10;
        }

        private void TickWriteLine(object sender, System.EventArgs e)
        {
            Debug.WriteLine("Control:" + sender + "\t" + e + "\t" + DateTime.Now.ToShortTimeString());
        }

        private void DebugWriteLine(object sender, System.EventArgs e)
        {
            Debug.WriteLine("Control:" + sender + "\t" + e);
        }

        private void TraceWriteLine(object sender, System.EventArgs e)
        {
            Trace.WriteLine("Control:" + sender + "\t" + e);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //TickWriteLine(sender, e);
            DateTime now = DateTime.Now;
            //this.label_timer.Text = now.GetDateTimeFormats("");
            this.label_timer.Text = now.ToString("yyyy/MM/dd-hh:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
        }

        //private void sendClick()
        //{
        //    ButtonAutomationPeer peer =  new ButtonAutomationPeer(someButton);
        //    IInvokeProvider invokeProv = peer.GetPattern(PatternInterface.Invoke) as IInvokeProvider;
        //    invokeProv.Invoke();
        //}

        const double INCH2CM = 2.54;
        const double LB2KG = 0.453592;

        private void button1_Click(object sender, EventArgs e)
        {
            TraceWriteLine(this.lastFocus, e);
            if (this.lastFocus == textBox_inch)
            {
                textBox_cm.Text = (double.Parse(textBox_inch.Text) * INCH2CM).ToString();
            }
            else if (this.lastFocus == textBox_cm)
            {
                textBox_inch.Text = (double.Parse(textBox_cm.Text) / INCH2CM).ToString();
            }
            else if (this.lastFocus == numericUpDown_inch)
            {
                numericUpDown_cm.Value = new decimal(decimal.ToDouble(numericUpDown_inch.Value) * INCH2CM);
            }
            else if (this.lastFocus == numericUpDown_cm)
            {
                numericUpDown_inch.Value = new decimal(decimal.ToDouble(numericUpDown_cm.Value) / INCH2CM);
            }
            else
            {
                textBox_Click(textBox_cm, EventArgs.Empty);
                button1_Click(sender, e);
                //textBox_Click(numericUpDown_cm, EventArgs.Empty);
                //button1_Click(sender, e);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.lastFocus == textBox_lb)
            {
                textBox_kg.Text = (double.Parse(textBox_lb.Text) * LB2KG).ToString();
            }
            else if (this.lastFocus == textBox_kg)
            {
                textBox_lb.Text = (double.Parse(textBox_kg.Text) / LB2KG).ToString();
            }
            else if (this.lastFocus == numericUpDown_lb)
            {
                numericUpDown_kg.Value = new decimal(decimal.ToDouble(numericUpDown_lb.Value) * LB2KG);
            }
            else if (this.lastFocus == numericUpDown_kg)
            {
                numericUpDown_lb.Value = new decimal(decimal.ToDouble(numericUpDown_kg.Value) / LB2KG);
            }
            else
            {
                textBox_Click(textBox_kg, EventArgs.Empty);
                button2_Click(sender, e);
                //textBox_Click(numericUpDown_kg, EventArgs.Empty);
                //button1_Click(sender, e);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox_inch.Text = (double.Parse(textBox_cm.Text) / INCH2CM).ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox_cm.Text = (double.Parse(textBox_inch.Text) * INCH2CM).ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox_lb.Text = (double.Parse(textBox_kg.Text) / LB2KG).ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox_kg.Text = (double.Parse(textBox_lb.Text) * LB2KG).ToString();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text File Only.(*.txt)|*.txt";
            saveFileDialog1.ShowDialog();
            //MessageBox.Show(saveFileDialog1.FileName);
            textBox1.Text = saveFileDialog1.FileName;
            try
            {
                File.WriteAllText(saveFileDialog1.FileName, "");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }


        //public static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        //{
        //    if (depObj != null)
        //    {
        //        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
        //        {
        //            DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
        //            if (child != null && child is T)
        //            {
        //                yield return (T)child;
        //            }
        //            foreach (T childOfChild in FindVisualChildren<T>(child))
        //            {
        //                yield return childOfChild;
        //            }
        //        }
        //    }
        //}
    }

}

﻿namespace WindowsFormsApp1
{
    public class Product
    {
        public Product()
        {
        }

        public string Name { get; set; }
        public int Price { get; set; }
    }
}